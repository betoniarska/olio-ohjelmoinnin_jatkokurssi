# Tehtävänanto - Harjoitustehtävät 1



***Tehtävien pisteytys:***  
Tehtävä 1: 6  
Tehtävä 2: 6  
Tehtävä 3: 6  
Tehtävä 4: 6  
Tehtävä 5: 6  


Yhteensä 30 pistettä

Aloita tehtävien tekeminen forkkaamalla ja/tai kloonaamalla git-projekti 
https://gitlab.utu.fi/tech/education/ooj/ooj2023-exercise1 

Valmiit tehtävät palautetaan Moodleen. Paketoi zip-pakettiin koko projekti ja lataa se Moodleen. 


***Mitä tarkoittaa määritys? Entä toteutus?***  
Jos tehtävässä pyydetään määrittämään, se tarkoittaa luokan ja/tai rutiinin signatuurin, alku- ja 
loppuehtojen sekä luokkainvariantin kirjoittamista eikä varsinaista työn tekevää rutiinin 
koodia tarvitse toteuttaa. Jos puolestaan pyydetään toteuttamaan jotain, yleensä rutiini, pitää rutiini koodata 
kokonaan valmiiksi. Vastaavasti, jos pyydetään määrittämää ja toteuttamaan, tehdään kaikki edellä mainittu.

Määrittelyt saavat olla formaaleja, mutta ei-formaali sanallinen esitystapa hyväksytään myös.

## Tehtävä 1

Tehtävän 1 vastaukset kirjoitetaan Main.java tiedostoon, jossa on valmiina paikat niille.

***A.*** Painoindeksi BMI lasketaan kaavalla BMI = paino / (pituus * pituus). Alla oleva rutiini laskee painoindeksin
parametreina saatujen tietojen avulla. Määrittele rutiinille alku- ja loppuehto niin, että rutiini toimii 
virheittä painoindeksin määrittelyn mukaan ja rutiinin palautusarvo on järkevä. Rutiinin koodia ei saa muuttaa.

```java
/* 
* Alkuehto:
* Loppuehto:
*/
public static Double laskeBMI(Double pituus, Double paino) {
        return (paino / (pituus * pituus));
        }
```
***B.*** Teemme toisen rutiinin painoindeksin laskentaan. Tällä kerralla sen alkuehto on true. Toteuta rutiini niin, 
että loppuehto pitää paikkansa ja poikkeus nostetaan tarvittaessa.
```java
/* 
* Alkuehto: true
* Loppuehto: lopputulos on (paino / (pituus * pituus) ja  lopputulos > 5 ja lopputulos < 250
* Poikkeukset: Nostaa poikkeuksen IllegalArgumentException, jos... [täydennä]
*/
public static Double laskeBMITurvallisesti(Double pituus, Double paino) throws IllegalArgumentException{
        
        }
```
***C.*** Määrittele ja toteuta rutiini kerroMatriisit, joka suorittaa parametreina annettujen matriisien kertolaskun. Rutiinin 
signatuurin on esitetty alla. Signatuurin annettuja osia ei saa muuttaa, mutta sitä saa täydentää esimerkiksi lisäämällä poikkeuksen.
Kiinnitä huomiota virhetilanteisiin ja sivuvaikutuksiin. Perustele tekemäsi suunnitteluratkaisut.

**Matriisien kertolasku (lainaus Wikipediasta):**  
Matriisien kertolaskussa tulomatriisi muodostuu ensimmäisen matriisin vaakariveistä ja toisen matriisin sarakkeista 
muodostettujen vektoreiden pistetuloista. Olkoon matriisi A kokoa *m × p* ja B kokoa p × n. Tällöin matriisien A ja B 
tulo AB on kokoa *m × n*. Nyt matriisitulo on

![matriisi](/images/matriisi1.svg)

missä kukin a<sub>i</sub> on matriisin A i:nnestä vaakarivistä muodostettu vektori, ja b<sub>i</sub> on matriisin 
B j:nnestä sarakkeesta muodostettu vektori. On tärkeää huomata, että matriisin A sarakkeiden määrän täytyy olla 
sama kuin matriisin B vaakarivien määrä. Muussa tapauksessa laskutoimitus ei ole määritelty.  

![matriisi2](/images/matriisi2.png)

**Esimerkki:**  
![matriisi3](/images/matriisi3.svg)![matriisi4](/images/matriisi4.svg)



```java
/*
* Alkuehto:
* Loppuehto
  */
  public static int[][] kerroMatriisit(int[][] matriisiA, int[][] matriisiB) 
  
```

**Pisteytys**: 6 pistettä
- A-kohta 2 pistettä: alkuehto 1 piste, loppuehto 1 piste
- B-kohta 1 piste
- C-kohta 3 pistettä


## Tehtävä 2

Tutustu tehtäväpohjassa oleviin Opiskelija- ja VuosiKurssi-luokkiin. Opiskelija mallintaa yksittäistä opiskelijaa ja 
VuosiKurssi samana vuonna opinnot aloittaneiden ryhmää.

Määrittelyt saavat olla formaaleja, mutta ei-formaali sanallinen esitystapa hyväksytään myös.

***A.*** Määrittele molemmille luokille julkinen luokkainvariantti. 

***B.*** Määrittele luokan VuosiKurssi  lisääOpiskelija-rutiinille  alku- ja loppuehdot niin, 
että ne turvaavat luokkainvariantin voimassaolon.

***C.*** Luokkaan halutaan lisätä lisääOpiskelijaTurvallisesti-rutiini. Se lisää opiskelijan vuosikurssille samoin kuin
olemassa oleva lisaaOpiskelija-rutiini, mutta tämän rutiinin alkuehto on *true*. Toteuta rutiinin niin, että se 
turvaa luokkainvariantin voimassaolon. 

***D.*** Lisää lisääOpiskelijaTurvallisesti-rutiiniin poikkeuskäsittely. Määrittele ja toteuta uusi 
InvalidStudentDataException-poikkeusluokka. Nosta InvalidStudentDataException-poikkeus lisaaKirjaTurvallisesti-rutiinissa, 
jos opiskelijaa ei voida luoda rikkomatta luokkainvarianttia.

**Pisteytys**: 6 pistettä
- A-kohta 2 pistettä
- B-kohta 2 piste
- C-kohta 1 pistettä
- D-kohta 1 pistettä




## Tehtävä 3

Kirjoita vastauksesi Apurutiinit.java tiedostoon.

***A.*** Tutustu Main-luokassa olevaan kuplaLajittelu-rutiiniin. Onko rutiinilla mahdollisia 
sivuvaikutuksia? Mitä ja miksi?  Korjaa koodista pois kaikki sivuvaikutukset. 
Pohdi lisäksi, mitä hyötyä tai haittaa on siitä, että kuplalajittelu on sivuvaikutuksellinen tai sivuvaikutukseton. 
Eritysesti pohdi, onko hyödyllistä toteuttaa sivuvaikutuksellinen kuplalajittelu.

***B.*** Uraansa aloitteleva sovelluskehittäjä on päätynyt eriyttämään eräitä usein käyttämiään rutiineita erilliseen 
Apurutiinit-luokkaan. Ideana on näppärästi asettaa luokan muuttujiin arvoja ja sitten käyttää niitä monessa 
eri rutiinissa helposti. 

Modernit ohjelmat käyttävät usein samanaikaisuutta ts. ohjelmassa on säikeitä, jotka suorittavat eri tehtäviä samaan 
aikaan itsenäisesti. Apurutiineita käytetään näissä kaikissa. Eri säikeissä samaan aikaan suoritettavat apurutiinin 
kutsut voivat lomittua.

Tutustu ja analysoi Apurutiinit luokan rutiinien toimintaa. Onko koodari unohtanut jotain vai onko 
ratkaisu mielekäs? Pohdi vastauksessasi, miten Apurutiini toimii erilaisissa tilanteissa. 
Voisiko Apurutiinin toteuttaa paremmin? Miten?

**Pisteytys**: 6 pistettä
- A-kohta 3 pistettä
- B-kohta 3 pistettä

## Tehtävä 4

Tehtävässä on tarkoitus valita parhaiten tarkoitukseen soveltuva luokkakonstruktio ja ***perustella*** valinta. 
Sopivia vaihtoehtoja voi olla useampiakin. Perustelu ratkaisee, hyväksytäänkö valintasi.

*Kaikki alla listatut ongelmat voi ratkaista myös konkreettisella perusluokalla, mutta sitä ei saa käyttää 
tässä tehtävässä.*

Sallitut vaihtoehdot ovat:
- abstrakti luokka
- esiintymäkohtainen sisäluokka
- funktioliteraalit - ja rajapinnat
- literaaliluokka
- nimetön luokka
- rajapinta
- staattinen sisäluokka
- suljettu luokka
- tietueluokka

Vastaukset kirjoitetaan Tehtava4Vastaukset.txt tiedostoon, joka on 
valmiina tehtäväpohjassa.

***A.*** Ohjelmaan halutaan lukea määrämuotoista tietoa tiedostosta. Tiedot ovat tiedostossa riveillä erotettuna 
pilkulla (CSV-tiedosto). Tietojenkenttien (sarakkeet) määrä ja tyypit tiedetään ja ne eivät muutu. Rivimäärää ei tunneta.
Luetut tiedot halutaan esittää muuttumattomina olioina, jotka on talletettu listaan. Mikä luokkakonstruktio valitaan 
kuvaamaan yhden rivin sisältämiä tietoja?

***B.*** Yksi tapa merkitä vaatteiden kokoja on kirjaintunnus: XXS, XS, S, M, L, XL, XL, XXL, XXXL. Jokaista 
kirjaintunnusta vastaa myös numeerinen arvo, joka halutaan yhdistää sitä vastaavaan kirjaintunnukseen. Yhdistämistä ei 
kuitenkaan haluta tehtävän merkkijonona ts. ei esimerkiksi M52 tai L54. Kirjaintunnus on ensisijainen tieto ja numeerinen 
tieto haetaan tarvittaessa sitä käyttäen. Kaikki koot ovat ennalta tiedossa. Mikä luokkakonstruktio luodaan kuvaamaan
vaatekokoja?

***C.*** Ohjelma käyttää erilaisia, toisilleen vaihtoehtoisia, tietovarastoja. Niitä ovat esimerkiksi eri 
tietokannat (esim. MySql, Postgres, Mongodb), tiedosto ja verkkoyhteys tietovarastoon. Tietovarastoon on määritelty vain 
yksinkertainen CRUD-toiminnallisuus (Create, read, update and delete). Jokainen varasto vaatii toimiakseen konkreetin 
java-luokan. Luokat sisältämät rutiinit ovat identtisiä signatuuritasolla, mutta rutiinien toteutukset eroavat.

Varsinaisen ohjelmalogiikan ei haluta riippuvan konkreetista toteutuksesta. Yhteys tietovarastoon eriytetään omaan 
pakettiinsa (package) ja ohjelmaan luodaan luokka, jonka avulla polymorfismia hyödyntäen ohjelmalogiikka käyttää 
tietovarastoa. Mikä luokkakonstruktio valitaan?

***D.*** Graafista käyttöliittymää käyttävissä ohjelmissa tapahtumankäsittelijät ovat rutiineja, jotka 
käyttöliittymäkirjasto suorittaa käyttäjän tehdessä toimintoja käyttöliittymässä. Esimerkiksi käyttäjän painaessa nappia 
suoritetaan kyseinen napin painamista vastaava tapahtumankäsittelijä. Tyypillisesti eri tapahtumien käsittely eroaa 
toistaan ja tapahtuman käsittelyyn tarvittavaa luokkaan käytetään ohjelmassa vain yhdessä kohdassa. Usein luokka ei 
myöskään sisällä muuta kuin käsittelyn delegoinnin eteenpäin. Mikä on useimmiten soveltuvin luokkakonstruktio tähän tarkoitukseen?

***E.*** Teemme kirjastorutiineja grafiikkaohjelmaa varten. Ohjelma tuntee rajoitetun määrän erilaisia muotoja: neliö, 
ympyrä, kolmio, suorakaide. Jokainen näistä kuvataan omana luokkanaan. Kaikilla edellä mainituilla on yhteisiä toimintoja
ja haluamme koota ne yhteiseen yliluokkaan RajattuMuoto, joka on yhteinen kaikille muodoille, jotka sulkevat rajaavat 
alueen. Haluamme, että yliluokan RajattuMuoto kehityksessä voidaan luottaa siihen, että sitä ei peri kuin soveltuvat 
luokat, eikä sitä voi vapaasti perimällä laajentaa. Mikä luokkakonstruktio on paras valinta?

***F.*** Jatkamme grafiikkaohjelman tekoa ja toteamme, että kaikilla kuvioilla on sekä samoja rutiineja, joiden 
toteutukset eroavat, että täysin identtisiä rutiineja. Haluamme määritellä kaikki ominaisuudet ja sen lisäksi 
toteuttaa täysin identtiset ominaisuudet samassa paikassa. Mikä on sopiva luokkakonstruktio tähän?


**Pisteytys**: 6 pistettä
- Sopiva valinta 0.5 pistettä per kohta
- Järkevä perustelu valinnalle 0.5 pistettä per kohta

## Tehtävä 5

Jono (queue) on FIFO-tietorakenne (first-in, first-out, ts. aikaisemmin tullutta palvellaan ensin).  

Jono tukee seuraavia operaatioita:  
- alkion lisäys jonon perään 
- jonon ensimmäisen alkion palautus 
- jonon ensimmäisen alkion poisto


Suunnittele luokan Jono määrittely ja toteutus huomioiden kapselointi:

***A.*** määrittele luokka ja edellä listatut rutiinit, julkinen liitäntä (rutiinien alku- ja loppuehdot, signatuurit)

***B.*** määritä luokalle luokkainvariantti

***C.*** toteuta suunnittelemasi rutiinit niin, että ne noudattavat alku- ja loppuehtoja sekä takaavat 
luokkainvariantin voimassaolon

***Javan standardikirjaston valmiita jono-luokkia ei saa käyttää tehtävässä.***

**Pisteytys**: 6 pistettä
- A-kohta 2 pistettä
- B-kohta 2 pistettä
- C-kohta 2 pistettä
