module fi.utu.tech.ooj.exercise1 {
    exports fi.utu.tech.ooj.exercise1;

    opens fi.utu.tech.ooj.exercise1;
}
