package fi.utu.tech.ooj.exercise1;

public class Opiskelija {

    /* Tehtävä 2A Määrittele luokkainvariantti
     *
     * Luokkainvariantti: 'etunumi' != null, 'sukunimi' != null, 'opiskelijaNumero' != null, 'syntymavuosi' >= 0.
     *                    Asetusmetodit eivät palauta null.
     */
    private String etunimi;
    private String sukunimi;
    private String opiskelijaNumero;
    private int syntymavuosi;

    public Opiskelija(String etunimi, String sukunimi, String opiskelijaNumero, int syntymavuosi){
        this.etunimi = etunimi;
        this.sukunimi = sukunimi;
        this.opiskelijaNumero = opiskelijaNumero;
        this.syntymavuosi = syntymavuosi;
    }

    public String getEtunimi() {
        return etunimi;
    }

    public void setEtunimi(String etunimi) {
        this.etunimi = etunimi;
    }

    public String getSukunimi() {
        return sukunimi;
    }

    public void setSukunimi(String sukunimi) {
        this.sukunimi = sukunimi;
    }

    public String getOpiskelijaNumero() {
        return opiskelijaNumero;
    }

    public void setOpiskelijaNumero(String opiskelijaNumero) {
        this.opiskelijaNumero = opiskelijaNumero;
    }

    public int getSyntymavuosi() {
        return syntymavuosi;
    }

    public void setSyntymavuosi(int syntymavuosi) {
        this.syntymavuosi = syntymavuosi;
    }


}
