package fi.utu.tech.ooj.exercise1;

public class InvalidStudentDataException extends Exception{
    public InvalidStudentDataException(String errorMessage){
        super(errorMessage);
    }
}
