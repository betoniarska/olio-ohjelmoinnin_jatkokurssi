package fi.utu.tech.ooj.exercise1;

public class Apurutiinit {
    private static int lukumaara;
    private static String teksti;

    public static void asetaArvot(int lkm, String text) {
        Apurutiinit.lukumaara = lkm;
        Apurutiinit.teksti = text;
    }
    public static String getTeksti() {
        return Apurutiinit.teksti;
    }

    public static  String toistaTekstia() {
        String tulos = "";
        for (int i=0; i<lukumaara; i++) {
            tulos += teksti;
        }
        return tulos;
    }
    public static void kaannaTekstiToisinpain() {
        teksti= new StringBuilder(teksti).reverse().toString();
    }

    public static void luoPalindromi() {
         teksti = teksti + new StringBuilder(teksti).reverse().toString().substring(1);
    }

}

/*
* 3A
*
* Sivuvaikutuksellinen rutiini saattaa johtaa hyvin vaikeasti huomattaviin ongelmiin. Jos halutaan rutiinin
* muuttavan alkuperäistä parametrina annettua taulukkoa, on ensinäkin turhaa luoda taulukkoon kokonaan uutta
* viittausta rutiinin sisällä. Tällöin myös kuplalajittelijan palautusominaisuus voitaisiin ulkoistaa
* toiselle tähän tiettyyn tehtävään tarkoitetulle havainnointimetodille.
*
* Mielestäni siis sivuvaikutuksista ei ole hyötyä kuplalajittelijan tapauksessa, vaan on helpompaa ja
* turvallisempaa toteuttaa lajittelija sen mukaan mitä sen halutaan tarkalleen tekevän.
*
* 3B
*
* Apurutiinit-luokan toteutus on ongelmallinen, sillä se johtaa vaikeasti huomattaviin sivuvaikutuksiin. Nyt apurutiinit-
* luokan kaikki rutiinit käyttävät samoja luokan attribuutteja 'lukumaara' ja 'teksti'. Tämä johtaa siihen, että rutiinit
* vaikuttavat toistensa toimintaan muuttamalla 'lukumaara' ja 'teksti' sisältämiä arvoja.
*
* Luontevampi ratkaisu toteuttaa apurutiinit-luokka voisi olla yhteisten attribuuttien sijaan se, että jokainen erillinen
* rutiini saisi suoritukseen tarvitsemansa arvot ja muuttujat rutiinikohtaisina parametreina. Tällä voitaisiin varmistaa
* se, että rutiinit toimivat toisistaan riippumattomina ja niitä voidaan kutsua helposti muualta ohjelmasta.
*
 */


