package fi.utu.tech.ooj.exercise1;

import java.util.ArrayList;

public class VuosiKurssi {

    /* Tehtävä 2A Määrittele luokkainvariantti
     *
     * Luokkainvariantti: getOpiskelijat() != null, getKurssinAloitusvuosi >= 0.
     */
    private int kurssinAloitusvuosi;
    private ArrayList<Opiskelija> opiskelijat;

    public VuosiKurssi(int kurssinAloitusvuosi){
        this.kurssinAloitusvuosi = kurssinAloitusvuosi;
        this.opiskelijat = new ArrayList<>();
    }

    public int getKurssinAloitusvuosi() {
        return kurssinAloitusvuosi;
    }

    public void setKurssinAloitusvuosi(int kurssinAloitusvuosi) {
        this.kurssinAloitusvuosi = kurssinAloitusvuosi;
    }

    public ArrayList<Opiskelija> getOpiskelijat() {
        return opiskelijat;
    }

    /* Tehtävä 2B
     * Määrittele  alku- ja loppuehdot
     *
     * Alkuehto: 'opiskelija' != null
     * Loppuehto: lisää Opiskelija tyyppisen instanssin 'opiskelijat' listaan.
     *            Vaikuttaa ainoastaan 'opiskelijat' listaan.
     */
    public void lisaaOpiskelija(Opiskelija opiskelija) {

        this.opiskelijat.add(opiskelija);
    }

    /* Tehtävä 2C Toteuta tämä rutiini
     * Tehtävä 2D Lisää lisääOpiskelijaTurvallisesti-rutiiniin poikkeuskäsittely
     *
     * @.pre true
     * @.post true
     *
     */
    public void lisaaOpiskelijaTurvallisesti(Opiskelija opiskelija) throws InvalidStudentDataException{

        if (opiskelija == null || opiskelija.getEtunimi() == null || opiskelija.getSukunimi() == null || opiskelija.getOpiskelijaNumero() == null){
            throw new InvalidStudentDataException("Error");
        }
        this.opiskelijat.add(opiskelija);
    }
}
