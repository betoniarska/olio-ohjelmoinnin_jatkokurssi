package fi.utu.tech.ooj.exercise1;

import java.util.Arrays;

/*
* Luokkainvariantti: 'alkiot' attribuutti sisältää aina taulukon joka voi olla tyyppiä 'Object' tai 'null'.
 */
public class Jono {
Object[] alkiot;
public Jono(){

    alkiot = new Object[0];

}
    /* Lisaa jonon ensimmäiseen indeksiin geneerisen tyypin 'lisattava'.
    *
    * Alkuehto: Alkio 'lisattava' ei ole null.
    * Loppuehto: Lisää Object-tyyppisen alkion jonoon, kasvattaa 'alkiot' pituutta yhdellä.
    */
    public void lisaaAlkio(Object lisattava){
        Object[] apu = new Object[alkiot.length + 1];

        for (int i = alkiot.length - 1; i >= 0; i--){
            apu[i + 1] = alkiot[i];
        }
        alkiot = apu;
        alkiot[0] = lisattava;
    }
    /* palautaEnsimmainen-rutiini palauttaa jonon ensimmaisen alkion.
    *
    * Alkuehto: 'alkiot' ei ole tyhjä.
    * Loppuehto: Palauttaa jonon ensimmäisen alkion.
     */
    public Object palautaEnsimmainen(){
        return this.alkiot[0];
    }
    /* poistaEnsimmainen-rutiini poistaa jonon ensimmäisen alkion.
    *
    * Alkuehto: 'alkiot' ei ole tyhjä.
    * Loppuehto: Poistaa jonon ensimmäisen alkion, lyhentää 'alkiot' pituutta yhdellä.
     */

    public void poistaEnsimmainen(){
        Object[] apu = new Object[alkiot.length - 1];

        for (int i = alkiot.length - 1; i > 0; i--){
            apu[i - 1] = alkiot[i];
        }
        alkiot = apu;
    }
}

