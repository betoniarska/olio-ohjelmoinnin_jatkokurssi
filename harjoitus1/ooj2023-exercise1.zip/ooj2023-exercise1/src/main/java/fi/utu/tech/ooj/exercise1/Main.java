package fi.utu.tech.ooj.exercise1;


import java.util.Arrays;

public class Main {


    /**
     * Main class.
     *
     * @param args Command line arguments
     */
    /* Tehtävä 1A
     * Alkuehto: 'Pituus' ja 'Paino' ovat tyyppiä Double, 50 < 'Pituus' < 250, 20 < 'Paino' < 800.
     * Loppuehto: Palauttaa Doublena painoindeksin syötetyillä arvoilla.
     *            Ei sivuvaikutuksia, ei muuta 'Pituus':ta tai 'Paino':a.
     */
    public static Double laskeBMI(Double pituus, Double paino) {
        return (paino / (pituus * pituus));
    }

    /* Tehtävä 1B
     *
     * Alkuehto: true
     * Loppuehto: lopputulos on (paino / (pituus * pituus) ja  lopputulos > 5 ja lopputulos < 250
     * Poikkeukset: Nostaa poikkeuksen IllegalArgumentException, jos parametrit 'paino' ja 'pituus'
     *              eivät tuota loppuehdon vaatimaa lopputulosta.
     */

    public static Double laskeBMITurvallisesti(Double pituus, Double paino) throws IllegalArgumentException {
        double lopputulos = (paino / (pituus * pituus));
        if (!(lopputulos > 5 && lopputulos < 100) || !(pituus instanceof Double)){
            throw new IllegalArgumentException("Painoindeksi ei voi olla < 5 tai > 100.");
        }
        return lopputulos;

    }
    /* Tehtävä 1 C
     *
     * Alkuehto: 'matriisiA' ja 'matriisiB' eivät saa olla 'null' ja sisältävät vain Integer-tyyppisiä alkioita.
     *           'matriisiA' sarakkeiden määrä tulee olla sama kuin 'matriisiB' vaakarivien määrä.
     *
     * Loppuehto: palauttaa Integer-tyyppisen matriisin joka on parametrien 'matriisiA' ja 'matriisiB' pistetulo.
     *            Ei sivuvaikutuksia, ei muuta 'matriisiA':ta tai 'matriisiB'tä.
     */
    public static int[][] kerroMatriisit(int[][] matriisiA, int[][] matriisiB) throws IllegalArgumentException {

        if (matriisiA.length != matriisiB[0].length){
            throw new IllegalArgumentException("Ei määritelty");
        }

        int[][] tulos = new int[matriisiA.length][matriisiB[0].length];

        for (int i = 0; i < matriisiA.length; i++){
            for (int j = 0; j < matriisiB[0].length; j++){
                for (int k = 0; k < matriisiB.length; k++){
                    tulos[i][j] = tulos[i][j] + (matriisiA[i][k] * matriisiB[k][j]);
                }
            }
        }
        return tulos;
    }

    /*
    * @.pre inArr != null
    * @.post RESULT sisältää kaikki syötteen alkiot ja on järjestetty nousevaan järjestykseen
     */
    public static int[] kuplaLajittelu(int[] inArr) {

        int[] outArr = new int[inArr.length];

        for (int i = 0; i < inArr.length; i++){
            outArr[i] = inArr[i];
        }
        int n = outArr.length;
        int temp = 0;

        for(int i=0; i < n; i++){
            for(int j=1; j < (n-i); j++){

                if(outArr[j-1] > outArr[j]){
                    //swap elements
                    temp = outArr[j-1];
                    outArr[j-1] = outArr[j];
                    outArr[j] = temp;
                }

            }
        }
        System.out.println("Kuplalajittelu tehty!");
        return outArr;
    }


    public static void main(String[] args) {












        /*Kuplalajittelun testaus
        * */



        int[] lukuja = {1, 34, 2, 67, 4, 3, 10, 5};
        System.out.println(Arrays.toString(kuplaLajittelu(lukuja)));

        //Tehtävä 3B testi
        Apurutiinit.asetaArvot(3, "saippuakauppias");

        //Luodaan toistettua tekstiä ja tulostetaan se
        System.out.println(Apurutiinit.toistaTekstia());

        //Käännetään teksti toisinpäin ja tulostetaan
        Apurutiinit.kaannaTekstiToisinpain();
        System.out.println(Apurutiinit.getTeksti());

        //Asetetaan arvot palindromin luontia varten
        Apurutiinit.asetaArvot(3, "testi");
        Apurutiinit.luoPalindromi();
        System.out.println(Apurutiinit.getTeksti());

        //Testataan, onko palindromin luominen onnistunut kääntämällä teksti ja
        //vertaamalla käännettyä tekstiä alkuperäiseen
        Apurutiinit.kaannaTekstiToisinpain();
        System.out.println(Apurutiinit.getTeksti());




        
    }
}
