package fi.utu.tech.ooj.exercise2;

public class Asiakasrekisteri {
}
