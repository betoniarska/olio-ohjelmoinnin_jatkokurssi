# DTEK0066 exercise 2 template

## Tehtävänanto

Tehtävänanto löytyy kurssiportaalista.

## Workflow

```bash
$ git clone https://gitlab.utu.fi/tech/education/ooj/ooj2023-exercise2
$ cd template-ooj

< tee tehtävät >

< editoi AUTHORS.TXT >

$ git add -A
$ git commit -m 'Add exercise implementations'
$ git remote add oma https://gitlab.utu.fi/omatunnus/ooj2023-exercise2
$ git push oma

< korjaa/täydennä tehtäviä >

$ git add -A
$ git commit -m 'Fix the exercise task 2'
$ git push oma
```

## Using Maven

```bash
$ mvn clean
$ mvn compile
$ mvn test
$ mvn exec:java
$ mvn javafx:run
$ mvn surefire-report:report
```

## Online report

See <https://gitlab.utu.fi/tech/education/ooj/ooj2023-exercise2/pages>

Your version: https://USERNAME.utugit.fi/ooj2023-exercise2/
