package fi.utu.tech.ooj.exercise2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Year;

/*
* 3C
*
* Turvataan luokkainvariantin olemassaolo testaamalla läpi kaikki luokan metodit luokkainvariantin määrittämillä ehdoilla jollain luokan
* Car tapauksella, minkä pitäisi täyttää ehtojen kriteerit.
 */

public class CarTest {
    @Test
    void testaaInvariantti(){

        Car auto = new Car("Saab", "Gripen", 2022, true, "HUI-HUI");

        assert(auto.getManufacturer() != null && auto.getManufacturer().trim().length() >=2 &&
                auto.getModel() != null && auto.getModel().trim().length() >=2 &&
                auto.getModelYear() != null && auto.getModelYear() > 1900 && auto.getModelYear() <= Year.now().getValue() &&
                auto.getRegistered() != null && auto.getRegisterNumber() != null &&
                (( auto.getRegistered() == true && auto.getRegisterNumber().trim().length() >=6 ) || ( auto.getRegistered() == false && auto.getRegisterNumber().equals(""))));
    }
    /*
    * Testin mukaan luokan metodit toimivat, kun auto on luotu luokkainvariantin määrittämiä sääntöjä noudattaen.
     */

}
