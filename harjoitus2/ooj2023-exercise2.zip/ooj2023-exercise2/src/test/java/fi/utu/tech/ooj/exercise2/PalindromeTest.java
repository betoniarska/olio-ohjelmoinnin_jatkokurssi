package fi.utu.tech.ooj.exercise2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/*
* 3C
*
* Palindrome-luokkaa testatessa on tärkeää testata seuraavat asiat: 1. jos syöte on tyhjä merkkijono, myös palaute on
* tyhjä. 2. Jos syöte ei ole jo valmiiksi palindromi, palautetaan muunnettu palindromi. 3. Jos syöte on jo valmiiksi palindromi,
* se ei muutu esim. saippuakauppias. 4. Lisäksi testataan että muunnettu sana on todella syötteen palindromi.
*
 */

public class PalindromeTest {

    @Test
    void tyhja(){ // testataan toimiiko palindrome metodi kun syöte on tyhjä merkkijono.

        assertEquals(Palindrome.convertToPalindrome(""), "");
    }

    @Test
    void tavallinenSana(){ //testataan palauttaako metodi syötteen käännettynä ympäri, kun syöte ei ole palindromi.

        String sana = "auto";
        String palindrome = "autotua";

        assertEquals(Palindrome.convertToPalindrome(sana), palindrome);

        // Tässä huomataan myös, että palautettu sana ei ole syötteen palindromi (ehto 4).
    }

    @Test
    void valmiiksiPalindrome(){ //Testataan palauttaako metodi syötteen, kun syöte on jo valmiiksi palindromi.
        String sana = "saippuakauppias";

        assertEquals(Palindrome.convertToPalindrome(sana), sana);
        // Metodissa ei ole erinäistä ominaisuutta joka testaisi onko syötteenä saatu sana jo valmiiksi palindromi, joten
        // se yrittää tehdä jo valmiista palindromista palindromin. Ominaisuus voisi olla helppo lisätä.
    }

}
/*
* Voidaan huomata että Metodi convertToPalindrome ei voi toimia, sillä koska substring alkuindeksi on vakioarvolla 2,
* joten palindromista jää aina puuttumaan yksi kirjain.
* Metodi convertToPalindrome ei myöskään toimi kun syöte on tyhjä merkkijono, sillä metodi convertToPalindrome ei palauta
* tyhjää merkkijonoa koska sen viimeinen indeksi on minimissään 2.
 */
