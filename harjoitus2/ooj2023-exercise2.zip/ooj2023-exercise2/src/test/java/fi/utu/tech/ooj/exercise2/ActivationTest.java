package fi.utu.tech.ooj.exercise2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/*
* 3B
*
* Testataan Activation-luokan parametricReLu metodin palauttamia arvoja kolmessa eri tapauksessa: kun x<0, kun x=0
* ja kun x>0. ParametricReLu metodin tulisi palauttaa alkuperäisen x:n arvon kun x>0, 0 kun x=0 ja a*x kun x<0.
* Koska parametrin a arvolle ei ole annettu mitään kriteerejä, ei sitä tarvitse ottaa huomioon testeissä.
 */
public class ActivationTest {


    @Test
    void pienempi(){ //testataan kun x<0

        Activation testaaja = new Activation();

        float x = -2.0f;
        float a = 0.5f;

        float tulos = testaaja.parametricReLU(x, a);

        assert(tulos == a*x);

    }

    @Test
    void suurempi(){ //testataan kun x>0

        Activation testaaja = new Activation();

        float x = 2.0f;
        float a = 0.5f;

        float tulos = testaaja.parametricReLU(x, a);

        assert(tulos == x);
    }
    @Test
    void yhtasuuri(){ // testataan kun x=0

        Activation testaaja = new Activation();

        float x = 0.0f;
        float a = 0.5f;

        float tulos = testaaja.parametricReLU(x, a);

        assert(tulos == x);
    }

    // Testien nojalla rutiini 'parametricReLu' toimii määrittelynsä mukaan.

}


