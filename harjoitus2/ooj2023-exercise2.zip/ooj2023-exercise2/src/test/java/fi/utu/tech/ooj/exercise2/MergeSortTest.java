package fi.utu.tech.ooj.exercise2;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/*
* 3A
*
* Testataan mergeSort ja merge erillisillä luokilla 'MegerSortTest ja MergeTest'.
 */

public class MergeSortTest {

    /*
     * Tarkistetaan että jos mergeSort saa tyhjän taulukon, se myös palauttaa tyhjän taulukon.
     */

    @Test
    void tyhja(){

        Sorting sorter = new Sorting();

        int[] a = {};
        int[] b = {};

        sorter.mergeSort(a); // tyhjä taulukko mergeSorttiin.

        assertArrayEquals(a, b);

    }
    @Test
    void useampi(){

        /*
         * Tarkistetaan lajitteleeko mergeSort suurempia taulukoita oikein.
         */

        Sorting sorter = new Sorting();

        int[] sekoitettu = {7, 2, 4, 1, 3, 6, 5, 9, 8};
        int[] lajiteltu = {1, 2, 3, 4, 5, 6, 7, 8, 9};

        sorter.mergeSort(sekoitettu); // lajitellaan taulukko 'sekoitettu' mergeSortilla.

        assertArrayEquals(sekoitettu, lajiteltu);


    }
    @Test
    void negatiivisia(){

        /*
         * Tarkistetaan lajitteleeko mergeSort oikein taulukoita, jotka sisältävät sekä negatiivisia, että
         * positiivisia arvoja.
         */

        Sorting sorter = new Sorting();

        int[] sekoitettu = {7, 2, -2, 4, 1, 3, 6, -1, 5, 9, 8, 0};
        int[] lajiteltu = {-2, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9};

        sorter.mergeSort(sekoitettu); // lajitellaan taulukko 'sekoitettu' mergeSortilla.

        assertArrayEquals(sekoitettu, lajiteltu);

    }
    @Test
    void valmiiksiLajiteltu(){

        /*
         * Testataan ettei mergeSort muuta jo valmiiksi lajiteltua taulukkoa.
         */

        Sorting sorter = new Sorting();

        int[] lajiteltu1 = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int[] lajiteltu2 = {1, 2, 3, 4, 5, 6, 7, 8, 9};

        sorter.mergeSort(lajiteltu1); // lajitellaan jo valmiiksi lajiteltu taulukko uudestaan.

        assertArrayEquals(lajiteltu1, lajiteltu2);

    }

}

class MergeTest{

    @Test
    void tyhja(){

        /*
        * tarkistetaan että alkuperäinen taulukko 'a' pysyy mergen jälkeenkin tyhjänä.
         */

        Sorting sorter = new Sorting();

        int[] a = {0};
        int[] l = {0};
        int[] r = {0};

        sorter.merge(a, l, r, 0, 0);

        assertArrayEquals(new int[0], a);
    }
    @Test
    void useampi(){

        /*
        * tarkistetaan että jos alkuperäinen taulukko 'a' sisältää useampia alkioita, se lajitellaan oikein.
         */

        Sorting sorter = new Sorting();

        int[] a = {4, 2, 1, 3};
        int[] l = {2, 4}; // 'a':n lajiteltu vasempi puoli.
        int[] r = {1, 3}; // 'a':n lajiteltu oikea puoli.

        sorter.merge(a, l, r, 2, 2); // Testataan 'merge':ä taulukolla, missä on 4 alkiota.


        assertArrayEquals(new int[]{1, 2, 3, 4}, a);

    }

    @Test
    void lajiteltu(){

        /*
        *
         */

        Sorting sorter = new Sorting();

        int[] a = {1, 2, 3, 4};
        int[] l = {1, 2};
        int[] r = {3, 4};

        sorter.merge(a, l, r, 2, 2);

        assertArrayEquals(new int[]{1, 2, 3, 4}, a);

    }
    @Test
    void yksi(){

        /*
         *
         */

        Sorting sorter = new Sorting();

        int[] a = {1};
        int[] b = {1};
        int[] c = {2};

        sorter.merge(a, b, c, 1, 1);

        assertArrayEquals(new int[1], a);
    }


}
