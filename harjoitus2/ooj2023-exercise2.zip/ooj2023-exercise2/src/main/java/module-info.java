module fi.utu.tech.ooj.exercise2 {
    exports fi.utu.tech.ooj.exercise2;

    opens fi.utu.tech.ooj.exercise2;
    exports fi.utu.tech.ooj.t2tietokanta;
    opens fi.utu.tech.ooj.t2tietokanta;
}
