package fi.utu.tech.ooj.exercise2;
import java.util.HashMap;

/*
* 1A
*
* Asiakasrekisteri voidaan toteuttaa HashMap-tietorakenteen avulla. HashMap on muotoa <String, Asiakas>,
* jossa yksittäisen asiakkaan tunnisteena voidaan tässä tapauksessa käyttää Asiakkaan nimeä. Täten
* asiakkaita on helppo löytää rekisteristä nimen perusteella. Asiakkaita voi lisätä rekisteriin ja poistaa
* rekisteristä luokan määrittelyn jälkeen.
*
 */

public class Asiakasrekisteri {
    private HashMap<String, Asiakas> rekisteri;

    public Asiakasrekisteri(){
        rekisteri = new HashMap<>();
    }
    public void lisaaAsiakas(Asiakas asiakas){

    }

}
