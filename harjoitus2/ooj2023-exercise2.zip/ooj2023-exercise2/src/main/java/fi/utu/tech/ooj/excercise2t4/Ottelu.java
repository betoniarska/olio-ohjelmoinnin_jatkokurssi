package fi.utu.tech.ooj.excercise2t4;

import java.lang.reflect.Array;
import java.util.ArrayList;

// Invariantti: Ottelun lajit ja urheilijat eivät voi olla tyhjiä.
// Jokainen ottelussa oleva 'Ottelija' voi osallistua jokaiseen ottelun lajiin.
public class Ottelu implements Urheilulaji{
    ArrayList<Urheilulaji> lajit; // tietyssä ottelussa kilpailtavat lajit ja niiden tyypit.
    ArrayList<Urheilija> urheilijat; // otteluun osallistuvat ottelijat
    // (jokaisella ottelijalla ominaisuutena suorituksista saadut pisteet)

    @Override
    public Urheilulaji getTyyppi(Urheilija urheilija) {return null;}

    @Override
    public int getSuoritustenMaara(Urheilija urheilija) {return 0;}

    @Override
    // alkuehto: Urheilijan tulee olla osa ottelua, urheilija != null.
    public void suorita(Urheilija urheilija) { }
    // loppuehto: muuttaa urheilijan kokonaispistemäärää riippuen siitä, kuinka hyvä kyseinen suoritus on.
    // Mikäli suoritus on hylätty, ei lisää pisteitä urheilijalle.
}
