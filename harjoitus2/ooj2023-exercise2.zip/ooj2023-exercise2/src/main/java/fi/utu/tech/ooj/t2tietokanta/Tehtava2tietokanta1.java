package fi.utu.tech.ooj.t2tietokanta;

import java.util.List;

public class Tehtava2tietokanta1<T> extends Tiedonkasittely<T>{

    public void lisaaTieto(T value) {
        //Toteutus poistettu. Se on merkityksetön tehtävän kannalta.
    }

    public List<T> haeTiedot() {
        //Toteutus poistettu. Se on merkityksetön tehtävän kannalta.
        return null;
    }

    public  void muokkaaTieto(T value, T newValue) {
        //Toteutus poistettu. Se on merkityksetön tehtävän kannalta.
    }
    public  void poistaTieto(T value) {
        //Toteutus poistettu. Se on merkityksetön tehtävän kannalta.
    }
}
