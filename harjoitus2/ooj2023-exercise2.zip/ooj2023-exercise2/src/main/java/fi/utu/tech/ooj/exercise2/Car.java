package fi.utu.tech.ooj.exercise2;

import java.time.Year;

public class Car {

    /*
     * @.classInvariant manufacturer != null && manufacturer.trim().length >=2 &&
     *                  model != null && model.trim().length >=2 &&
     *                  modelYear != null && modelYear > 1900 && modelYear <= Year.now().getValue() &&
     *                  isRegistered != null && registerNumber != null &&
     *                  (( isRegistered == true && registerNumber.trim.length >=6 ) ||
     *                  ( isRegistered == false && registerNumber = "" ))
     */
    private String manufacturer;
    private String model;

    private Integer modelYear;
    private Boolean isRegistered;
    private String registerNumber;

    public String getManufacturer() {
        return manufacturer;
    }

    /*
     *  @.pre true
     *  @.post true
     */
    public void setManufacturer(String manufacturer) throws IllegalArgumentException {
        if (manufacturer == null || manufacturer.isBlank() || manufacturer.trim().length() <2) {
            throw new IllegalArgumentException();
        }
        this.manufacturer = manufacturer;
    }

    public String getModel() {
        return model;
    }

    /*
     *  @.pre true
     *  @.post true
     */
    public void setModel(String model) throws IllegalArgumentException {
        if (model == null || model.isBlank() || model.trim().length() <2) {
            throw new IllegalArgumentException();
        }
        this.model = model;
    }

    public Integer getModelYear() {
        return modelYear;
    }

    /*
     *  @.pre true
     *  @.post true
     */
    public void setModelYear(Integer modelYear) throws IllegalArgumentException {
        if (modelYear == null || modelYear <= 1900 || modelYear > Year.now().getValue()) {
            throw new IllegalArgumentException();
        }
        this.modelYear = modelYear;
    }

    public Boolean getRegistered() {
        return isRegistered;
    }

    /*
     *  @.pre true
     *  @.post true
     */
    public void setRegistered(Boolean registered) throws IllegalArgumentException{
        if (registered == null) {
            throw new IllegalArgumentException();
        }
        isRegistered = registered;
    }

    public String getRegisterNumber() {
        return registerNumber;
    }

    /*
     *  @.pre true
     *  @.post true
     */
    public void setRegisterNumber(String registerNumber) throws IllegalArgumentException{
        if (registerNumber == null || registerNumber.isBlank() || registerNumber.trim().length() >=6) {
            throw new IllegalArgumentException();
        }
        this.registerNumber = registerNumber;
    }

    /*
     * @.pre            manufacturer != null && manufacturer.trim().length >= 2 &&
     *                  model != null && model.trim().length >= 2 &&
     *                  modelYear != null && modelYear > 1900 && modelYear <= Year.now().getValue() &&
     *                  isRegistered != null && registerNumber != null &&
     *                  (( isRegistered == true && registerNumber.trim.length >= 6 ) ||
     *                  ( isRegistered == false && registerNumber = "" ))
     * @.post           true
     */
    public Car(String manufacturer, String model, Integer modelYear, Boolean isRegistered, String registerNumber) {
        this.manufacturer = manufacturer;
        this.model = model;
        this.modelYear = modelYear;
        this.isRegistered = isRegistered;
        this.registerNumber = registerNumber;
    }

    /*
     * @.pre            manufacturer != null && manufacturer.trim().length >= 2 &&
     *                  model != null && model.trim().length >= 2 &&
     *                  modelYear != null && modelYear > 1900 && modelYear <= Year.now().getValue()
     * @.post           true
     */
    public Car(String manufacturer, String model, Integer modelYear) {
        this.manufacturer = manufacturer;
        this.model = model;
        this.modelYear = modelYear;
        this.isRegistered = false;
        this.registerNumber = "";
    }
}
