package fi.utu.tech.ooj.exercise2;
import java.util.HashMap;

/*
*
* Samaan tapaan kuin Tuoteluettelossa, Laskussa voidaan käyttää tuottelistauksen tekemiseen HashMappia. HashMap on
* muotoa <String, Tuote>, missä kunkin tuotteen nimi toimii tuotteen avaimena HashMapissa. 'tunniste'
*
 */

class Lasku{
    private HashMap<String, Tuote> tuotteet;

    public Lasku(){
        tuotteet = new HashMap<>();
    }

    /*
     * kokonaisHinta palauttaa 'tuotteet' listan sisältämien tuotteiden kokonaishinnan.
     * Ottaa myös huomioon mahdolliset asetetut alennukset.
     */
    public Double kokonaisHinta(){
        return null;

    }
    /*
    * setAlennus Voidaan hakea laskun tuotelistasta tietty tuote ja asettaa kyseiselle tuotteelle tuotteen 'Alv'-attribuutin
    * määrittämä alennus.
     */
    public void setAlennus(Tuote tuote){

    }
    /*
    * Kohdistaa laskun parametrina saadulle asiakkaalle.
     */
    public void laskuta(Asiakas asiakas){

    }

}
