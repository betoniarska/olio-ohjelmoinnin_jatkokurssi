package fi.utu.tech.ooj.exercise2;
import java.util.HashMap;

/*
* 1B
*
* Samoin kuin Asiakasrekisteri, Tuoteluettelo voidaan toteuttaa HashMap-tietorakenteen avulla.
* HashMap on muotoa <String, Tuote>, jossa yksittäisen tuotteen tunnisteena voidaan tässä tapauksessa
* käyttää Tuotteen nimeä. Täten tuote on helppo löytää luettelosta nimen perusteella. Tuotteita voi
* lisätä luetteloon ja poistaa luettelosta luokan määrittelyn jälkeen.
*
 */
public class Tuoteluettelo {
    HashMap<String, Tuote> luettelo;

    public Tuoteluettelo() {
        luettelo = new HashMap<>();
    }
}
