package fi.utu.tech.ooj.excercise2t4;

import java.util.HashMap;


/*
* Kilpailutapahtuma ominaisuudet: kilpailutapahtumalla on nimi ja luettelo kilpailtavista urheilulajeista.
* Kullakin urheilulajilla on omat listansa lajeihin osallistuvista kilpailijoista. Juoksukilpailun tapauksessa
* karsintaerissä voidaan kilpailuun osallistujia karsia suoritteiden pistetulosten mukaan.
*
* Kilpailutapahtuman urheilulajit määritellään tapahtuman luomisen yhteydessä.
 */

/*
* Luokkainvariantti: 'nimi' ei ole tyhjä merkkijono
* 'lajit' sanakirjan sisältämien urheilulajien tulee olla uniikkeja. Esim maratooni voi esiintyä vain kerran kilpailutapahtumaa
* kohden, mutta erilaisia juoksutapahtumia voi olla monia samassa kilpailussa.
* Jokaisessa kilpailussa on oltava vähintään yksi kilpailija kussakin urheilulajissa.
* Jokainen urheilija on samaa tyyppiä, kuin laji mihin osallistuu.
 */
public class Kilpailutapahtuma {

    private String nimi; // tapahtuman nimi (esim. olympialaiset, triathlon etc)
    private HashMap<String, Urheilulaji> lajit; // avain: lajin nimi, arvo: laji. Eli kilpailussa kilpailtavat urheilulajit.
    // tärkeää: jokainen urheilulaji sisältää omat kyseisessä kilpailussa kilpailevat urheilijansa.


    // Alkuehto: kilpailussa on oltava vähintään yksi kilpailija. Kilpailu tulee olla suoritettu.
    // Syötteenä annetun urheilulajin on oltava osa kilpailutapahtumaa.
    Urheilija getVoittaja(Urheilulaji urheilulaji){return null;}
    // Loppuehto: palauttaa syötteenä saadun urheilulajin kilpailusta kilpailijan, jolla on eniten pisteitä.

}
