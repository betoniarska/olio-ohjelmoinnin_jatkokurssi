package fi.utu.tech.ooj.excercise2t4;


public interface Urheilulaji{
    Urheilulaji getTyyppi(Urheilija urheilija); // Palauttaa syötteenä annetun urheilijan urheilulajin
    // Esimerkiksi jos kyseessä on juoksija, tarkemmin vaikkapa maratoonari, metodi juoksijan juoksulajin.

    int getSuoritustenMaara(Urheilija urheilija); // Voidaan selvittää montako suoritusta kullakin urheilijalla on.

    void suorita(Urheilija urheilija); // Suoritus riippuu syötteenä annetun uhreilijan lajista, mikäli laji on osa kilpailutapahtumaa
    // Suorituksia voi olla monia. Paras suoritus jää voimaan urheilijan pistetilastoon.
    // Lisää yhden suorituksen urheilijan kokonaissuorituksiin.
}

/*
*
*
*
 */

