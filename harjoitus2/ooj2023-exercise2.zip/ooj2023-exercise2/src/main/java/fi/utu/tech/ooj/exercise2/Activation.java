package fi.utu.tech.ooj.exercise2;

public class Activation {

    public static float parametricReLU(float x, float a) {
        if (x>0) {
            return x;
        }
        return a*x;
    }
}
