package fi.utu.tech.ooj.exercise2;

/*
* 1B
*
* Luokkainvariantti: mikään attribuuteista ei ole null.
*
* 'normaalihinta' ja 'Alv' eivät voi olla < 0.
* 'Alv' ei voi olla > 1.00.
*
 */

public class Tuote {
    String nimi;
    Double normaalihinta;
    Double Alv;

    public Tuote(String nimi, Double normaalihinta, Double alv) {
        this.nimi = nimi;
        this.normaalihinta = normaalihinta;
        this.Alv = alv;
    }

    public String getNimi() {
        return nimi;
    }

    public void setNimi(String nimi) {
        this.nimi = nimi;
    }

    public Double getNormaalihinta() {
        return normaalihinta;
    }

    public void setNormaalihinta(Double normaalihinta) {
        this.normaalihinta = normaalihinta;
    }

    public Double getAlv() {
        return Alv;
    }

    public void setAlv(Double alv) {
        Alv = alv;
    }
}
