package fi.utu.tech.ooj.excercise2t4;

import java.util.ArrayList;

/*
* Päätin toteuttaa urheilijoiden kokonaisuuden luomalla jokaista urheilulajia (Juoksu, Heitto etc) oman luokkatyyppinsä
* koska tällä tavalla tyyppi 'Ottelu' oli helppo ratkaista samaan tapaan kuin muutkin urheilulajit. Toisin sanoen Ottelu eroaa
* muista urheilulajeista ominaisuuksiltaan niin paljon, että mielestäni oli helpompaa luoda kullekkin urheilijalle oma
* luokkansa sen sijaan, että kaikki urheilijat olisivat olleet esimerkiksi kaikkea osaavan 'Yleisurheilija'-tyypin alla.
*
*
 */

public abstract class Urheilija {
    private String nimi;
    private int kokonaispisteet;
}

// Luokkainvariantti: 'kokonaispisteet' >= 0, 'lajit' listan arvot ovat osa Ottelua.
// 'nimi' ei voi olla tyhjä merkkijono.
class Ottelija extends Urheilija{
    private String nimi;
    private ArrayList<Urheilulaji> lajit; // ottelusta riippuen listaus urheilulajeista, joihin ottelija osallistuu.
    // Joustava lajien määrä mahdollistaa esimerkiksi kymmenottelun toteuttamisen.
    private int kokonaispisteet; // yhteenlaskettu pistemäärä kaikista lajeista, mitä ottelija on suorittanut.
    // kriteerinä sille, karsiutuuko urheilija vai ei.

}
// muun tyyppiset urheilijat kuin ottelijat omaavat miltei samat ominaisuudet pisteytystapaa lukuunottamatta.
// myös luokkainvariantit ovat samat.


// Luokkainvariantti: 'pistemaara' <= 0, 'suoritusaika' <= 0, laji != null.
class Juoksija extends Urheilija{

    private String nimi; // kilpailijan nimi
    private Urheilulaji laji; // urheilulaji, mihin kyseinen urheilija osallistuu.
    private int pistemaara; // kriteeri sille, karsiutuuko urheilija. Paras suoritus jää voimaan.
    private int suoritusaika; // pisteitä saa suoritusajan eli sijoituksen mukaan

}

// --..--
class Kavelija extends Urheilija{

    private String nimi;
    private Urheilulaji laji;
    private int pistemaara;
    private int suoritusaika;
}

class Hyppaaja extends Urheilija{
    private String nimi;
    private Urheilulaji laji;
    private int pistemaara;
    private int hyppykorkeus;
}
class Heittaja extends Urheilija{
    private String nimi;
    private Urheilulaji laji;
    private int pistemaara;
    private int heittopituus;

}




