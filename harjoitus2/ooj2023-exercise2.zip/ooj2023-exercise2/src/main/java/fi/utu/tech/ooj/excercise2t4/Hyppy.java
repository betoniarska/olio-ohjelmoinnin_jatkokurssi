package fi.utu.tech.ooj.excercise2t4;

import java.util.ArrayList;

// --..--
public class Hyppy implements Urheilulaji{

    private ArrayList<Hyppaaja> kilpailijat;
    private Urheilulaji tyyppi;

    @Override
    public Urheilulaji getTyyppi(Urheilija urheilija) {return null;}

    @Override
    public int getSuoritustenMaara(Urheilija urheilija) {return 0;}

    @Override
    public void suorita(Urheilija urheilija) {}

}


