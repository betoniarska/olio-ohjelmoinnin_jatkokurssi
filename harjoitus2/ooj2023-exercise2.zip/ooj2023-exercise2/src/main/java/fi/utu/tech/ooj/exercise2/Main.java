package fi.utu.tech.ooj.exercise2;


import java.util.Arrays;

public class Main {


    /**
     * Main class.
     *
     * @param args Command line arguments
     */


    public static void main(String[] args) {
        /*
         * Testin jälkeen alla olevan rivin voi joko kommentoida tai poistaa.
         */
        System.out.println("*** Harjoitustyöpohja käynnistyy ***");

        int[] someIntegers = { 5, 1, 6, 2, 3, 4 };
        System.out.println("Unsorted array: " + Arrays.toString(someIntegers));
        Sorting.mergeSort(someIntegers);
        System.out.println("Sorted array: " + Arrays.toString(someIntegers));

        System.out.println(Palindrome.convertToPalindrome("jari"));
    }
}
