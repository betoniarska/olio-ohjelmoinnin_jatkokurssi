package fi.utu.tech.ooj.exercise2;

/*
* Luokkainvariantti: mikään Asiakkaan attribuuteista ei ole null.
*
* postinumero.length() == 5.
* 'puhelinnumero' sisältää vain numeroita.
* 'nimi' sisältää vain kirjaimia.
*
 */

public class Asiakas {
    String nimi;
    String katuosoite;
    String postinumero;
    String postitoimipaikka;
    String puhelinnumero;

    public Asiakas(String nimi, String katuosoite, String postinumero, String postitoimipaikka, String puhelinnumero) {
        this.nimi = nimi;
        this.katuosoite = katuosoite;
        this.postinumero = postinumero;
        this.postitoimipaikka = postitoimipaikka;
        this.puhelinnumero = puhelinnumero;
    }

    public String getNimi() {
        return nimi;
    }

    public void setNimi(String nimi) {
        this.nimi = nimi;
    }

    public String getKatuosoite() {
        return katuosoite;
    }

    public void setKatuosoite(String katuosoite) {
        this.katuosoite = katuosoite;
    }

    public String getPostinumero() {
        return postinumero;
    }

    public void setPostinumero(String postinumero) {
        this.postinumero = postinumero;
    }

    public String getPostitoimipaikka() {
        return postitoimipaikka;
    }

    public void setPostitoimipaikka(String postitoimipaikka) {
        this.postitoimipaikka = postitoimipaikka;
    }

    public String getPuhelinnumero() {
        return puhelinnumero;
    }

    public void setPuhelinnumero(String puhelinnumero) {
        this.puhelinnumero = puhelinnumero;
    }
}


