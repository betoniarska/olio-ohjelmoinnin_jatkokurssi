package fi.utu.tech.ooj.exercise2;

import fi.utu.tech.ooj.t2tietokanta.Tiedonkasittely;

class Tehtava2ohjelmalogiikka{

    private Tiedonkasittely tietopalvelu;

    public Tehtava2ohjelmalogiikka(Tiedonkasittely tieto) {
        this.tietopalvelu = tieto;
    }

    public void teeJotain() {
        /*
            Ohjelmassa käytetään rutiineita, jotka on toteutettu Tehtava2tiedostopalvelu-luokassa.
            Tässä esimerkissä on kuvattu vain yksi ohjelmalogiikkaan kuuluva luokka. Todellisuudessa
            luokkia on useita ja ne kaikki riippuvat suoraan konkreetista Tehtava2tiedostopalvelu-luokasta.

            tietopalvelu.haeTiedot();
            tietopalvelu.lisaaTieto(value);
            tietopalvelu.muokkaaTieto(value, newValue)
            tietopalvelu.poistaTieto(value)
         */
    }
}
