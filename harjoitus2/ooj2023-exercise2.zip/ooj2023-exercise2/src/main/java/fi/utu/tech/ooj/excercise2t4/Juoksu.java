package fi.utu.tech.ooj.excercise2t4;

import java.util.ArrayList;

// Tärkeää: Luokat Hyppy, Heitto, Kavely seuraavat miltei samaa logiikkaa kuin luokka Juoksu.
// Tämän takia olen päättänyt käyttää luokkaa Juoksu suunnitteluratkaisujeni selittämiseen ja
// jättänyt identtiset kommentit edellämainituista luokista lisäämättä.

// Poikkeuksena luokka Ottelu, jossa on omat selitykset.

/*
* Luokkainvariantti: Kaikkien kilpailijoiden tulee olla saman tyyppisiä urheilijoita
* Kaikkien kilpailijoiden tyyppi on sama kuin Juoksu-luokan tyyppi.
* Kilpailijoita tulee olla vähintään yksi.
* suoritusten määrä <= 0, kilpailijalle annetut pisteet eivät voi olla <0.
 */

public class Juoksu implements Urheilulaji{

    /*
     * sisältää kilpailutapahtumakohtaisesti kilpailuun osallistuvat urheilijat, joita voidaan tarvittaessa
     * karsia suoritteiden pistetulosten mukaan. Sama pätee myös muille uhreilulajeille, mikäli tarvitaan
     * mahdollisuus pitää karsintakierroksia.
     */
    private ArrayList<Juoksija> kilpailijat;
    // 'kilpailijat' muuttujan sisältämillä juoksijoilla tulee olla sama urheilulaji, kuin muuttujassa 'tyyppi'


    private Urheilulaji tyyppi; // Juoksulajin tarkempi määrittely (esim. maratooni tai 400m)
    // Kilpailutapahtuma voi sisältää monia juoksutapahtumia eri tyyppimäärittelyillä.


    // Alkuehto: urheilija != null
    @Override
    public Urheilulaji getTyyppi(Urheilija urheilija) {return null;}

    // Loppuehto: palauttaa syötteenä annetun urheilijan tarkan urheilulajin.

    // Alkuehto: urheilijan on oltava osa kilpailua.
    @Override
    public int getSuoritustenMaara(Urheilija urheilija) {return 0;}

    // Loppuehto: palauttaa syötteenä annetun urheilijan suoritusten määrän.

    // Alkuehto: urheilijan on oltava osa kilpailua.
    @Override
    public void suorita(Urheilija urheilija) {}
    // loppuehto: antaa urheilijalle pisteet riippuen siitä, kuinka hyvä kyseinen suoritus on.
    // Mikäli suoritus on hylätty, ei lisää pisteitä urheilijalle.


    // Alkuehto: Juoksijan on oltava osa kilpailua
    void karsi(Juoksija juoksija){}// voidaan karsia kilpailijat, joilla ei ole tarpeeksi pisteitä jaatkoon.

    // Loppuehto: poistaa kilpailijoista syötteenä annetun juoksijan.
}




