package fi.utu.tech.ooj.t2tietokanta;

import java.util.List;

public abstract class Tiedonkasittely<T> {

    public abstract void lisaaTieto(T tieto);
    public abstract List<T> haeTiedot();
    public abstract void muokkaaTieto(T value, T newValue);
    public abstract void poistaTieto(T value);
}

/*
* t.2 perustelut
*
* Toteutin abstraktion luomalla kaikille mahdollisille 't2tietokanta' paketin luokille oman abstraktin yliluokan, jolla on geneerinen tyyppi
* <T>. Näin voidaan eriyttää suora yhteys ohjelmalogiikasta konkreetin toteutuksen tekeviin luokkiin. Ohjelmalogiikka
* ei siis ole suoraan riippuvainen konkreettien luokkien toteutuksista, vaan abstraktion avulla konkreetteja luokkia
* voidaan käyttää joustavasti ohjelmalogiikasta käsin. Nyt siis kaikkiin abstraktin luokan 'Tiedonkäsittely' periviin luokkiin
* on mahdollista päästä käsiksi 'Tiedonkäsittely' luokan kautta. Abstraktion olisi voinut myös toteuttaa rajapinnalla abstraktin luokan sijaan.
*
* Abstraktio ja polymorfismi mahdollistavat ns. joustavammat ohjelmakokonaisuudet, sillä niiden avulla konkreetit toteutukset voidaan eriyttää
* ohjelmalogiikasta. Polymorfismin avulla esimerkiksi ainoastaan toteutukseltaan eriävät luokat voidaan yhdistää samaan kokonaisuuteen. Toisaalta
* abstraktion ja polymorfismin myötä ohjelman ymmärrettävyys saattaa kärsiä.
*
 */
