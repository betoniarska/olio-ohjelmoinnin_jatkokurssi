package fi.utu.tech.ooj.excercise2t4;

import java.util.ArrayList;

public class Heitto implements Urheilulaji{

    private ArrayList<Heittaja> kilpailijat;
    private Urheilulaji tyyppi;
    @Override
    public Urheilulaji getTyyppi(Urheilija urheilija) {return null;}

    @Override
    public int getSuoritustenMaara(Urheilija urheilija) {return 0;}

    @Override
    public void suorita(Urheilija urheilija) {}
}

