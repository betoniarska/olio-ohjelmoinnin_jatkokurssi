package fi.utu.tech.ooj.exercise2;

public class Palindrome {

    public static String convertToPalindrome(String textIn) {
        return textIn + new StringBuilder(textIn).reverse().toString().substring(2);
    }
}
