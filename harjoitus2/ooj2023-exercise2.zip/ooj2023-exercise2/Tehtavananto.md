# Tehtävänanto - Harjoitustehtävät 2



***Tehtävien pisteytys:***  
Tehtävä 1: 6  
Tehtävä 2: 6  
Tehtävä 3: 8  
Tehtävä 4: 10

Yhteensä 30 pistettä

Aloita tehtävien tekeminen forkkaamalla ja/tai kloonaamalla git-projekti 
https://gitlab.utu.fi/tech/education/ooj/ooj2023-exercise2 

Valmiit tehtävät palautetaan Moodleen. Paketoi zip-pakettiin koko projekti ja lataa se Moodleen. 

### Tärkeää

Ammattimaisessa ohjelmoinnissa varsinaisen koodin kirjoittamista tärkeämpää on suunnittelu. Olio-ohjelmoinnissa 
luokkakokonaisuuksien hyvä suunnittelu on ensiarvoista. Kuten kurssin alussa on todettukin, Olio-ohjelmoinnin jatkokurssin 
painotus ei niinkään ole varsinaisessa rutiinien koodaamisessa vaan ohjelman hyvin perustellussa suunnittelussa ja dokumentoinnissa. 

Samoin on myös tämän kertaisissa tehtävissä. Tehtävissä ei pääosin vaadita toteutusta kuin signatuurien kirjoittamisen osalta. Vain testaustehtävässä kirjoitetaan 
ohjelma (testit) valmiiksi asti.

Tehtävät ovat varsin väljästi kuvattu aivan tarkoituksella. Tämä jättää tekijälle enemmän vapauksia soveltaa kurssilla opittuja 
asioita. On tärkeää pohtia ratkaisut tarkkaan ja perustella tehdyt ratkaisut. Toimivan loppuun asti koodatun ohjelman sijaan
arvostelussa painotetaan toimivia suunnitteluratkaisuja ja ERITYISESTI niiden perusteluja. Dokumentointia voi kirjoittaa joko 
java-tiedostoihin tai erillisiin teksti- tai pdf-tiedostoihin. Pyydän välttämään Word tms. tiedostotyyppejä. 

Jos tuntuu siltä, että tehtävänannossa ei jotain ratkaisevaa tietoa ole, voi tehdä oman tulkinnan ja perustella sen. 
Vaihtoehtoisesti voi asiasta keskustella Discordissa kuitenkaan kuvaamatta omia ratkaisuja yksityiskohtaisesti. Myös ohjaajilta saa
toki apua kysyä.

***Mitä tarkoittaa määritys? Entä toteutus?***  
Jos tehtävässä pyydetään määrittämään, se tarkoittaa luokan ja/tai rutiinin signatuurin, alku- ja 
loppuehtojen sekä luokkainvariantin kirjoittamista eikä varsinaista työn tekevää rutiinin 
koodia tarvitse toteuttaa. Jos puolestaan pyydetään toteuttamaan jotain, yleensä rutiini, pitää rutiini koodata 
kokonaan valmiiksi. Vastaavasti, jos pyydetään määrittämää ja toteuttamaan, tehdään kaikki edellä mainittu.

Määrittelyt saavat olla formaaleja, mutta ei-formaali sanallinen esitystapa hyväksytään myös.

## Tehtävä 1

**Luokkakokonaisuuden suunnittelu**


Olet saanut tehtäväksesi ohjelmoida yksinkertaisen laskutusohjelman. Työn pohjaksi saat 
lyhyen kuvauksen yrityksen toiminnasta.

Oy Jekku Ab valmistaa ja myy pilailutarvikkeita. Yritys harjoittaa vain tukkukauppaa ja 
kaikki myynti tapahtuu laskulle. Yrityksellä on asiakkaita, jotka kaikki kirjataan 
asiakasrekisteriin. Yrityksen valmistamat tuotteet puolestaan ovat tuoteluettelossa.

Näiden perusteella luodaan lasku, joka kohdistuu asiakkaalle ja laskutettavat tuotteet 
ovat tuoteluettelon tuotteita. Laskussa on 1-n riviä tuotteita. 
Laskutuksessa voidaan antaa kertaluonteisia alennuksia tuotekohtaisesti ja tämäkin 
pitää pystyä laskussa huomioimaan. 

Asiakkaasta rekisteriin on kirjattuna
- nimi
- katuosoite
- postinumero
- postitoimipaikka
- puhelinnumero

Tuotteesta tiedetään
- nimi
- normaalihinta
- ALV-prosentti

Lasku perustuu asiakkaan tekemään tilaukseen. Tilausta itsessään ei tarvitse mallintaa tässä harjoituksessa. 

***A.*** Määrittele luokat asiakasrekisterille ja yksittäiselle asiakkaalle. Perustele ratkaisusi.  
***B.*** Määrittele vastaavasti luokat tuoteluettelolle ja tuotteelle. Perustele ratkaisusi.    
***C.*** Määrittele laskuun liittyvät luokat. Perustele ratkaisusi.

**Perustele vastauksesi huolella kaikissa tehtäväkohdissa. Tehtävään ei ole yhtä oikeaa vastausta. 
Suunniteltujen ratkaisujen perustelu on avainasemassa arvostelussa. Pohdi erityisesti luokkien vastuita ja kapselointia.**

**Pisteytys**: 6 pistettä
- A-kohta 2 pistettä
- B-kohta 2 piste
- C-kohta 2 pistettä


## Tehtävä 2

On olemassa linnustotutkimusdataa käyttävä sovellus. Se käyttää tietojen
tallentamiseen CSV-tiedostoa. Nykyinen version ohjelman varsinainen logiikka riippuu 
ikävästi suoraan tiedostojen lukemisen konkreetista toteutuksesta. 

Olemme tekemässä uutta versiota, jossa tietojen tallentaminen halutaan eriyttää omaan 
pakettiinsa. Samalla haluamme, että ohjelmalogiikka eriytetään konkreetin toteutuksen tekevistä 
luokista sopivalla abstraktiolla. Lisäksi lisätään tiedostoon tallentamisen rinnalla yhteys 
tietokantaan. Sekä tiedoston että tietokannan toiminnallisuudet ovat ohjelmalogiikan 
kannalta samoja.

Tehtäväpohjasta löytyy luokat Tehtava2ohjelmalogiikka, Tehtava2tiedostopalvelu ja 
Tehtava2tietokanta1. Ne kuvaavat yksinkertaista lähtötilannetta, jossa Tehtava2ohjelmalogiikka 
riippuu suoraan Tehtava2tietokanta1-luokasta. 

Määriotä ja toteuta  luokkarakenne siten, että Tehtava2ohjelmalogiikka ei enää riipu mistään konkreetista
toteutuksesta ja erilaisia toteutuksia tarjoavat luokat Tehtava2tietokanta1 ja Tehtava2tiedostopalvelu
on siirretty omaan pakettiinsa, josta riiputaan polymorfismia hyödyntäen.

Perustele. Miten ja miksi päädyit tähän ratkaisuun? Mitä hyötyä tai haittaa abstraktiosta ja polymofismista tässä 
tapauksessa on?

**Pisteytys**: 6 pistettä
- abstraktio toteutettu, eikä ohjelmalogiikka riipu enää toteutuksesta 2 pistettä
- tietoyhteyden omassa paketissaan 1 piste
- suunniteluratkaisujen perustelu. Miten ja miksi päädyit tähän ratkaisuun? 2 pistettä
- hyötyjä ja haittoja pohdittu järkevästi 1 piste

## Tehtävä 3

***A.*** Tehtäväpohjan luokassa Sorting on toteutettu lajittelurutiini mergeSort ja sen 
käyttämä apurutiini merge. 
- Tutustu rutiineihin ja määrittele, mitä asioita testien pitää testata?
- Tee niille yksikkötestit käyttäen JUnit-kirjastoa. MergeSort ja merge
halutaan molemmat testata erikseen. Toimiiko lajittelu oikein?

***B.*** Activation-luokassa on toteutettu rutiini parametricReLU. 
- Tutustu rutiiniin ja määrittele, mitä asioita testien pitää testata?  
- Toteuta rutiiniin löytämiesi vaatimusten testaaminen assert lauseella. Toimiiko rutiini määrittelynsä mukaan?

*Huomaa, että oletuksena assertions ei ole Javassa toiminnassa vaan se pitää kytkeä päälle
erikseen Java virtuaalikoneen parametrillä -ea Parametrin saa asetettua käyttöön myös IDE-ympäristöissä*


***C.*** Palindrome-luokassa on rutiini convertToPalindrome, joka tekee syötteenä saamastaan
merkkijonosta palindromin. 
- Tutustu rutiiniin ja määrittele, mitä asioita testien pitää testata?
- Tee sille yksikkötestit käyttäen JUnit-kirjastoa. Toimiiko rutiini oikein?

***D.*** Tutustu tehtävä pohjasta löytyvään Car-luokkaan. 
- Suunnittele yksikkötestit, jotka tarkastavat säilyttävätkö luokan rutiinit luokkainvariantin vaatimukset.
- Toteuta edellä suunnitellut yksikkötestit käyttäen JUnit-kirjastoa.


**Pisteytys**: 8 pistettä
- A-kohta 2 pistettä: 1 piste testattavien asioiden määrittely, 1 piste Junit testit
- B-kohta 2 pistettä: 1 piste testattavien asioiden määrittely, 1 piste assert
- C-kohta 2 pistettä: 1 piste testattavien asioiden määrittely, 1 piste Junit testit
- D-kohta 2 pistettä: 1 piste testattavien asioiden määrittely, 1 piste Junit testit


## Tehtävä 4

Viimeisessä tehtävässä suunnittelemme jälleen luokkakokonaisuuden. Tehtävän ongelmakuvaus on väljempi
kuin edellisissä tehtävissä. Ideana on antaa enemmän vapauksia tehtävän tekijälle soveltaa 
kurssilla opetettuja asioita. Erityisesti huomiota tulee kiinnittää hyvään luokkasuunnitteluun, 
luokkien vastuisiin, kapselointiin ja suojaukseen. 

Suunnittelemme ohjelmaa erilaisten yleisurheilukilpailujen suoritusten kirjaamiseen. Sitä varten
haluamme mallintaa luokkakokonaisuudeksi erilaisten urheilulajien suoritusten pisteytystä. Ohjelma tuntee 
erilaisia urheilulajeja ja niissä kilpailevat urheilijat. Urheilulajeista voi koota kilpailutapahtuman. 
Kilpailutapahtumia voi olla useita.

Määritä luokkahierarkia ja toteuta se signatuuritasolla tärkeimpien ominaisuuksien osalta. Toteuta siis 
luokat ja niiden tärkeimmät rutiinit kirjoittaen niiden pelkät signatuurit. Tärkeimmät rutiinit voi 
ymmärtää siten, että luokkakokonaisuuden täytyy sisältää ainakin ne rutiinit, jotka tarvitaan kokonaisuuden
toimintatavan ymmärtämiseen. 

***Mitään rutiineja ei tarvitse toteuttaa.***

Erityisen tärkeää tehtävässä on suunnittelupäätösten dokumentointi. Miten ja miksi olet päätynyt johonkin ratkaisuun?

Ohjelman tulee tuntea seuraavien lajityyppien arvostelu:
- juoksulajit
- hyppylajit
- heittolajit
- kävelyt
- ottelut, jotka koostuvat edellä mainituista lajityypeistä

**Lajeista pitää huomioida ainakin seuraavat ominaisuudet:**  

Juoksulajit
- maaliintulojärjestys ts. suoritusaika ratkaisee voittajan
- vain yksi suoritus per juoksija per karsintaerä, mutta ennen finaalia voi olla useita karsintoja 

Hyppylajit
- hypätty pituus tai korkeus ratkaisee
- useita suorituksia per urheilija, joista paras ratkaisee

Heittolajit
- heitetty pituus ratkaisee
- useita suorituksia per urheilija, joista paras ratkaisee


Kävelyt 
- maaliintulojärjestys ts. suoritusaika ratkaisee voittajan
- vain yksi suoritus per kävelijä, ei karsintoja (oikeasti karsintoja voi olla, mutta ei tässä tehtävässä)

Ottelu
- kooste edellä mainituista lajeista
- osasuorituksista saa pisteitä ja eniten pisteitä saanut voittaa
- pisteiden määrä per osasuoristus ja kokonaispistemäärä voivat vaihdella eri otteluissa

Yleistä lisätietoa lajeista, jos aihepiiri on vieras:
https://fi.wikipedia.org/wiki/Yleisurheilu


**Pisteytys**: 10 pistettä
- luokkakokonaisuuden järkevyys ja sen perustelu. Onko rakenne toimiva? Ovatko luokkien vastuut selvät? 2 pistettä
- perinnän ja polymorfismin käyttö 1 piste
- luokkien suojaukset 1 piste
- määrittelyt: luokkainvariantit, alku- ja loppuehdot 2 pistettä
- Toteutukset signatuuritasolla 2 pistettä
- suunnittelupäätösten perustelu 2 pistettä
