package fi.utu.tech.ooj.exercise3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Kirjasto implements Cloneable{

    private String kirjastonNimi;
    private String osoite;
    private List<KirjaKokoelma> kokoelmat = new ArrayList<>();
    private Set<Kirjasto> sivukirjastot = new HashSet<>();

    public Kirjasto(String kirjastonNimi, String osoite) {
        this.kirjastonNimi = kirjastonNimi;
        this.osoite = osoite;
    }

    public Set<Kirjasto> getSivukirjastot() {
        return sivukirjastot;
    }


    public String getKirjastonNimi() {
        return kirjastonNimi;
    }

    public void setKirjastonNimi(String kirjastonNimi) {
        this.kirjastonNimi = kirjastonNimi;
    }

    public String getOsoite() {
        return osoite;
    }

    public void setOsoite(String osoite) {
        this.osoite = osoite;
    }

    public List<KirjaKokoelma> getKokoelmat() {
        return kokoelmat;
    }

    public void lisaaKokoelma(KirjaKokoelma input) throws IllegalArgumentException {
        if (input == null || input.getkokoelmanNimi() == null || input.getkokoelmanNimi().isBlank()) {
            throw new IllegalArgumentException("Virheelliset kirjastotiedot");
        }
        kokoelmat.add(input);
    }

    public void lisaaSivukirjasto(Kirjasto input) throws IllegalArgumentException {
        if (input == null || input.getKirjastonNimi() == null || input.getOsoite() == null
                || input.getKirjastonNimi().isBlank() || input.getOsoite().isBlank()) {
            throw new IllegalArgumentException("Virheelliset kirjastotiedot");
        }
        sivukirjastot.add(input);
    }

    @Override
    public Kirjasto clone() throws CloneNotSupportedException{

        Kirjasto kirjasto = (Kirjasto) super.clone();

        kirjasto.kokoelmat = new ArrayList<>();
        for (KirjaKokoelma kokoelma : kokoelmat){
            kirjasto.kokoelmat.add(kokoelma.clone());
        }
        kirjasto.sivukirjastot = new HashSet<>();
        for (Kirjasto sivu : sivukirjastot){
            kirjasto.sivukirjastot.add(sivu.clone());
        }

        return kirjasto;

    }

    @Override
    public String toString(){

        String kokoelma = "Pääkirjasto: \n";

        for (KirjaKokoelma kokoelma1 : kokoelmat){
            kokoelma += kokoelma1.toString() + "\n";
        }

        String sivut = "";

        if (sivukirjastot.size() > 0){
            sivut = "Sivukirjastot: \n";

            for (Kirjasto kirjasto : sivukirjastot){
                sivut += kirjasto.toString();
            }

            return kokoelma + sivut;
        }

        return kokoelma;

    }
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Kirjasto kirjasto = (Kirjasto) obj;


        return  kirjastonNimi.equals(kirjasto.kirjastonNimi) && osoite.equals(kirjasto.osoite) &&
                kokoelmat.equals(kirjasto.kokoelmat) &&
                new ArrayList<>(sivukirjastot).equals(new ArrayList<>(kirjasto.sivukirjastot));

    }


}
