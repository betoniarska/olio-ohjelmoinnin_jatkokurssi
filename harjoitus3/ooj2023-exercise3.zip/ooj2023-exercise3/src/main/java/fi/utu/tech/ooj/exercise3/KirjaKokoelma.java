package fi.utu.tech.ooj.exercise3;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class KirjaKokoelma implements Cloneable{

    private String kokoelmanNimi;
    private  ArrayList<Kirja>kirjaListaus;

    public KirjaKokoelma(String kokoelmanNimi) {
        this.kokoelmanNimi = kokoelmanNimi;
        this.kirjaListaus = new ArrayList<>();
    }

    public String getkokoelmanNimi() {
        return kokoelmanNimi;
    }

    public void setkokoelmanNimi(String kokoelmanOmistaja) {
        this.kokoelmanNimi = kokoelmanNimi;
    }

    public ArrayList<Kirja> getKirjaListaus() {
        return kirjaListaus;
    }

    public void lisaaKirja(Kirja teos) {
        kirjaListaus.add(teos);
    }

    @Override
    public KirjaKokoelma clone() throws CloneNotSupportedException{

        KirjaKokoelma uusi = (KirjaKokoelma) super.clone();

        uusi.kirjaListaus = new ArrayList<>();
        for (Kirja kirja : kirjaListaus){
            uusi.kirjaListaus.add(kirja.clone());
        }

        return uusi;
    }

    @Override
    public String toString(){
        String kirjat = "";
        for (Kirja kirja : kirjaListaus){
            kirjat = kirjat + kirja.toString() + "\n";
        }
        return "Kokoelma: " + kokoelmanNimi + "\n" + "Kirjat: " + "\n" + kirjat;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        KirjaKokoelma kokoelma = (KirjaKokoelma) obj;

        if (!kokoelmanNimi.equals(kokoelma.kokoelmanNimi)) {
            return false;
        }

        if (!kirjaListaus.equals(kokoelma.kirjaListaus)) {
            return false;
        }

        return true;
    }

}
