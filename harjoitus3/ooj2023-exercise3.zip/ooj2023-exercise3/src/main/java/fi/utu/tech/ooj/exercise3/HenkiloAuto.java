package fi.utu.tech.ooj.exercise3;

public class HenkiloAuto extends Ajoneuvo{

    private int henkiloMaara;
    public HenkiloAuto(String rekisteriNumero, String omistaja, int henkilot) {
        super(rekisteriNumero, omistaja);
        this.henkiloMaara = henkilot;
    }

    public int getHenkiloMaara() {
        return henkiloMaara;
    }

    public void setHenkiloMaara(int henkiloMaara) {
        this.henkiloMaara = henkiloMaara;
    }
}
