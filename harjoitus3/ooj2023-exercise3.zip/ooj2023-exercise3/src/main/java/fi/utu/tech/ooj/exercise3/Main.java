package fi.utu.tech.ooj.exercise3;

import java.util.*;


import java.util.HashMap;
import java.util.HashSet;

public class Main {


    /**
     * Main class.
     *
     * @param args Command line arguments
     */


    public static void main(String[] args) {
        /*
         * Testin jälkeen alla olevan rivin voi joko kommentoida tai poistaa.
         */
        System.out.println("*** Harjoitustyöpohja käynnistyy ***");

        HashSet<Ajoneuvo> ajoneuvot = new HashSet<Ajoneuvo>();
        HashSet<HenkiloAuto> henkiloautot = new HashSet<HenkiloAuto>();
        HashSet<KuormaAuto> kuormaautot = new HashSet<KuormaAuto>();

        // tehtävä 2 testit:

        Kirjasto paakirjasto = new Kirjasto("Oodi", "Töölönlahdenkatu 4, 00100 Helsinki");
        Kirjasto sivukirjasto1 = new Kirjasto("Feeniks", "Henrikinkatu 2, 20500 Turku");
        paakirjasto.lisaaSivukirjasto(sivukirjasto1);
        Kirjasto sivukirjasto2 = new Kirjasto("Pasilan kirjasto", "Kellosilta 9, 00520 Helsinki");
        paakirjasto.lisaaSivukirjasto(sivukirjasto2);

        KirjaKokoelma kokoelma1 = new KirjaKokoelma("Tiede");
        KirjaKokoelma kokoelma2 = new KirjaKokoelma("Fantasia");
        paakirjasto.lisaaKokoelma(kokoelma1);
        paakirjasto.lisaaKokoelma(kokoelma2);
        KirjaKokoelma kokoelma3 = new KirjaKokoelma("Ohjelmointi");
        KirjaKokoelma kokoelma4 = new KirjaKokoelma("Tietokoneet");
        sivukirjasto1.lisaaKokoelma(kokoelma3);
        sivukirjasto1.lisaaKokoelma(kokoelma4);
        KirjaKokoelma kokoelma5 = new KirjaKokoelma("Komedia");
        KirjaKokoelma kokoelma6 = new KirjaKokoelma("Sarjakuvat");
        sivukirjasto2.lisaaKokoelma(kokoelma5);
        sivukirjasto2.lisaaKokoelma(kokoelma6);

        Kirja kirja1 = new Kirja("Joku", "Aarni", 2002);
        Kirja kirja2 = new Kirja("Joku", "Jaakko", 2003);
        kokoelma1.lisaaKirja(kirja1);
        kokoelma1.lisaaKirja(kirja2);
        Kirja kirja3 = new Kirja("Joku", "Ville", 2004);
        Kirja kirja4 = new Kirja("Joku", "Tamzid", 2005);
        kokoelma2.lisaaKirja(kirja3);
        kokoelma2.lisaaKirja(kirja4);
        Kirja kirja5 = new Kirja("Joku", "Jasmin", 2006);
        Kirja kirja6 = new Kirja("Joku", "Janina", 2002);
        kokoelma3.lisaaKirja(kirja5);
        kokoelma3.lisaaKirja(kirja6);
        Kirja kirja7 = new Kirja("Joku", "Heidi", 2002);
        Kirja kirja8 = new Kirja("Joku", "Asta", 200125);
        kokoelma4.lisaaKirja(kirja7);
        kokoelma4.lisaaKirja(kirja8);
        Kirja kirja9 = new Kirja("Joku", "Noora", 2002);
        Kirja kirja10 = new Kirja("Joku", "Jätti", 2002);
        kokoelma5.lisaaKirja(kirja9);
        kokoelma5.lisaaKirja(kirja10);
        Kirja kirja11 = new Kirja("Joku", "asdasd", 2002);
        Kirja kirja12 = new Kirja("Joku", "asdasdasd", 2002);
        kokoelma6.lisaaKirja(kirja11);
        kokoelma6.lisaaKirja(kirja12);

        System.out.println(paakirjasto.toString());

        try {

            Kirjasto klooni = paakirjasto.clone();

            if (paakirjasto.equals(klooni)){
                System.out.println("Kirjastot ovat samat");
            } else {
                System.out.println("Kloonaus ei toimi");
            }
        } catch (CloneNotSupportedException e){
            System.out.println(e);
        }

        // Tehtävä 3 demonstrointi:

        Map<String, Integer> testi = new HashMap<>();

        testi.put("Omena", 5);
        testi.put("Banaani", 2);
        testi.put("Nakki", 76);
        testi.put("Pallo", 12);

        RandomMap<String, Integer> satunnainen = new RandomMap<>(testi);

        System.out.println("\nT3 testit:");

        System.out.println(satunnainen.get("Omena"));
        System.out.println(satunnainen.get("Peruna"));
        System.out.println(satunnainen.get("Lamppu"));

    }
}
