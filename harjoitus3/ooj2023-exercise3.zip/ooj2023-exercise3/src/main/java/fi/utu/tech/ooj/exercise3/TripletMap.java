package fi.utu.tech.ooj.exercise3;

import java.util.Set;
public interface TripletMap <K, V, W>{
    void put(K key, V value1, W value2);

    V getFirstValue(K key);

    W getSecondValue(K key);

    void remove(K key);

    void clear();

    Set<K> keySet();

    Set<V> firstValues();

    Set<W> secondValues();

    boolean containsKey(Object key);

    boolean containsValue(Object value1, Object value2);

    boolean isEmpty();

    int size();
}
