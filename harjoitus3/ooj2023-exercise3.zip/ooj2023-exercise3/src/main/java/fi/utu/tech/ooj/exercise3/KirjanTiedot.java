package fi.utu.tech.ooj.exercise3;

/*
 * Literaaliluokka, joka listaa kirjaa liittyvät tietokentät
 */
public enum KirjanTiedot {
    NIMI,
    KIRJAILIJA,
    JULKAISUVUOSI
}
