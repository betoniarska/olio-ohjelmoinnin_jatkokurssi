package fi.utu.tech.ooj.exercise3;

public class KuormaAuto extends Ajoneuvo{
    private int kantavuus;


    public KuormaAuto(String rekisteriNumero, String omistaja, int lasti) {
        super(rekisteriNumero, omistaja);
        this.kantavuus = lasti;
    }
}
