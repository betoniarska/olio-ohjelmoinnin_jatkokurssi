package fi.utu.tech.ooj.exercise3;

import java.util.Set;
import java.util.TreeSet;

abstract class Ajoneuvo {

    private String rekisteriNumero;
    private String omistaja;

    public Ajoneuvo(String rekisteriNumero, String omistaja) {
        this.rekisteriNumero = rekisteriNumero;
        this.omistaja = omistaja;
    }


    public String getRekisteriNumero() {
        return rekisteriNumero;
    }

    public void setRekisteriNumero(String rekisteriNumero) {
        this.rekisteriNumero = rekisteriNumero;
    }

    public String getOmistaja() {
        return omistaja;
    }

    public void setOmistaja(String omistaja) {
        this.omistaja = omistaja;
    }

    public static <X extends Z, Y extends Z, Z extends Ajoneuvo> Set<Z> yhdista(Set<X> xs, Set<Y> ys){
        var tmp = new TreeSet<Z>();
        for (var x : xs) tmp.add(x);
        for (var y : ys) tmp.add(y);
        return tmp;
    }

    /*
    * 5A
    *
    * Paluuarvona saadun listan tyyppi on <Z>, joka tässä tapauksessa tarkoittaa yliluokkaa 'Ajoneuvo'.
    * Tämä tarkoittaa, että tuloksena saadun listan kanssa yhteensopivia tyyppisignatuureja ovat kaikki
    * 'Ajoneuvo'-luokan aliluokat.
    *
    * 5B
    *
    * Koska 'HenkiloAuto' ja 'KuormaAuto' ovat luokan 'Ajoneuvo' alityyppejä, voidaan listat 'henkiloautot'
    * ja 'kuormaautot' lisätä listaan 'ajoneuvot'.
    *
    * Kuitenkin koska HashSet<KuormaAuto> ja HashSet<HenkiloAuto> eivät ole alityyppejä HashSet<Ajoneuvo>:lle,
    * emme voi lisätä listojen 'henkiloautot' ja 'kuormaautot' viittauksia listaan 'ajoneuvot'. Voimme korjata
    * tilanteen luomalla HashSet-instanssin joka käyttää 'Ajoneuvo' tyyppiä parametrinaan.
    * Korjattu määrittely: HashSet<Ajoneuvo> ajoneuvot = new HashSet<Ajoneuvo>();Koska 'ajoneuvot' on
    * nyt yhteensopiva 'HashSet<Ajoneuvo>'-tyypin kanssa, se pystyy käsittelemään 'Ajoneuvo'-luokan alityyppejä.
    *
     */
}
