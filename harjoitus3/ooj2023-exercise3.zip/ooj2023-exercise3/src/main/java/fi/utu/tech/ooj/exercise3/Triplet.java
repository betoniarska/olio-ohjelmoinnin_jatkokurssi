package fi.utu.tech.ooj.exercise3;

import java.util.*;
public class Triplet <K, V, W> implements TripletMap <K, V, W>{
    private final HashMap<K, HashMap<V, W>> map;

    public Triplet(){
        this.map = new HashMap<>();
    }

    @Override
    public void put(K key, V value1, W value2) {
        map.computeIfAbsent(key, k -> new HashMap<>()).put(value1, value2);
    }

    @Override
    public V getFirstValue(K key) {
        return map.get(key).keySet().iterator().next();
    }

    @Override
    public W getSecondValue(K key) {
        return map.get(key).values().iterator().next();
    }

    @Override
    public void remove(K key) {

    }

    @Override
    public void clear() {
        map.clear();
    }

    @Override
    public Set<K> keySet() {
        return map.keySet();
    }

    @Override
    public Set<V> firstValues() {
        Set<V> firstValues = new HashSet<>();

        for (K key : map.keySet()) {
            firstValues.add(getFirstValue(key));
        }

        return firstValues;

    }

    @Override
    public Set<W> secondValues() {
        Set<W> secondValues = new HashSet<>();

        for (K key : map.keySet()) {
            secondValues.add(getSecondValue(key));
        }

        return secondValues;
    }

    @Override
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }

    @Override
    public boolean containsValue(Object value1, Object value2) {
        return firstValues().contains(value1) && secondValues().contains(value2);
    }

    @Override
    public boolean isEmpty() {
        return map.isEmpty();
    }

    @Override
    public int size() {
        return map.size();
    }
}
