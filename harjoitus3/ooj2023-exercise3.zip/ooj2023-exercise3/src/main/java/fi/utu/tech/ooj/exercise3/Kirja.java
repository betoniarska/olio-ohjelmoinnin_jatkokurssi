package fi.utu.tech.ooj.exercise3;

import java.util.Objects;

public class Kirja implements Cloneable {
    private String kirjanNimi;
    private String kirjailijanNimi;
    private int julkaisuVuosi;

    public Kirja(String kirjanNimi, String kirjailijanNimi, int julkaisuVuosi) {
        this.kirjanNimi = kirjanNimi;
        this.kirjailijanNimi = kirjailijanNimi;
        this.julkaisuVuosi = julkaisuVuosi;
    }

    public String getKirjanNimi() {
        return kirjanNimi;
    }

    public void setKirjanNimi(String kirjanNimi) {
        this.kirjanNimi = kirjanNimi;
    }

    public String getKirjailijanNimi() {
        return kirjailijanNimi;
    }

    public void setKirjailijanNimi(String kirjailijanNimi) {
        this.kirjailijanNimi = kirjailijanNimi;
    }

    public int getJulkaisuVuosi() {
        return julkaisuVuosi;
    }

    public void setJulkaisuVuosi(int julkaisuVuosi) {
        this.julkaisuVuosi = julkaisuVuosi;
    }

    @Override
    public Kirja clone() throws CloneNotSupportedException{
        return (Kirja) super.clone();
    }
    @Override
    public String toString(){
        return "Nimi: " + kirjanNimi + ", Kirjailija: " + kirjailijanNimi +  ", Julkaisuvuosi: " + julkaisuVuosi;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Kirja kirja = (Kirja) obj;

        if (julkaisuVuosi != kirja.julkaisuVuosi) {
            return false;
        }

        if (!kirjanNimi.equals(kirja.kirjanNimi)) {
            return false;
        }

        if (!kirjailijanNimi.equals(kirja.kirjailijanNimi)) {
            return false;
        }

        return true;
    }
}