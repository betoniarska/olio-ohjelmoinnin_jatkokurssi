# Tehtävänanto - Harjoitustehtävät 3



***Tehtävien pisteytys:***  
Tehtävä 1: 4  
Tehtävä 2: 8  
Tehtävä 3: 5  
Tehtävä 4: 9  
Tehtävä 5: 4

Yhteensä 30 pistettä

Aloita tehtävien tekeminen forkkaamalla ja/tai kloonaamalla git-projekti 
https://gitlab.utu.fi/tech/education/ooj/ooj2023-exercise3 

Valmiit tehtävät palautetaan Moodleen. Paketoi zip-pakettiin koko projekti ja lataa se Moodleen. 


***Mitä tarkoittaa määritys? Entä toteutus?***  
Jos tehtävässä pyydetään määrittämään, se tarkoittaa luokan ja/tai rutiinin signatuurin, alku- ja 
loppuehtojen sekä luokkainvariantin kirjoittamista eikä varsinaista työn tekevää rutiinin 
koodia tarvitse toteuttaa. Jos puolestaan pyydetään toteuttamaan jotain, yleensä rutiini, pitää rutiini koodata 
kokonaan valmiiksi. Vastaavasti, jos pyydetään määrittämää ja toteuttamaan, tehdään kaikki edellä mainittu.

Määrittelyt saavat olla formaaleja, mutta ei-formaali sanallinen esitystapa hyväksytään myös.

## Tehtävä 1

Tehtäväsi on miettiä, miten luokat eroavat toisistaan ja mihin käyttötarkoitukseen luokkia voisi käyttää. Mitkä
ovat seuraavien luokkien oleelliset erot?

***A.*** Collection ja Map  
***B.*** List, Set ja Queue  
***C.*** ArrayList ja LinkedList  
***D.*** HashSet ja TreeSet

**Pisteytys**: 4 pistettä, 1 piste per kohta


## Tehtävä 2

Tutustu tehtäväpohjan luokkiin Kirjasto, KirjaKokoelma, Kirja ja Kirjantiedot. 

Kirjasto-luokka kuvaa kirjaston toimipistettä. Kirjaston toimipisteellä voi olla sivukirjastoja, jotka niin ikään ovat 
saman Kirjasto-luokan olioita. Myös sivukirjastolla voi olla sivukirjastoja. Kirjasto-luokalla on Set-tyyppinen 
muuttuja sivukirjastot. Se jää tyhjäksi, jos kyseisellä kirjastolla ei ole sivukirjastoja.  

Voimme esimerkiksi Turun seudulla ajatella, että Turun pääkirjasto on Kirjasto-olioista syntyvän puun juurisolmu. 
Sen omat sivukirjastot ja naapurikuntien pääkirjastot ovat Turun pääkirjastoa kuvaavan olion sivukirjastoja. Naapurikuntien 
pääkirjastoilla voi olla omia sivutoimipisteitä, jotka muodostavat puun kolmannen tason. Puun syvyyttä ei ole rajattu.

Jokaisella kirjastolla on useita kirjakokoelmia, esim. erityyppisiä kirjoja (kaunokirjallisuus, tietokirjat, 
lasten kirjat jne.). Jokaiseen kokoelmaan kuuluu puolestaan kirjoja. 

***A.*** **Kloonaus.** Haluamme, että kuvatun luokkakokonaisuuden luokkien kloonauksessa syntyy aina syväkopio. Toteuta 
luokkiin clone-rutiinit niin, että syväkopiointi toteutuu. Esimerkiksi pääkirjastona (puun juurisolmu) toimivan 
clone-rutiinia kutsuttaessa haluamme saada kopiot kaikista olioista, joihin pääkirjaston oliosta on jotain reittiä 
yhteys (viittauksia olioiden välillä).

***B.*** **Merkkijonoesitys.** Toteuta luokkiin toString-rutiinit niin, että se palauttaa merkkijonoesityksenä luokan 
jäsenmuuttujien nimet ja arvot. Jos jäsenmuuttuja on tyypiltään kokoelmaluokka, kutsutaan sen alkioiden toString-rutiineja. 
Kiinnitä erityistä huomiota tekstin luettavuuteen. Esimerkiksi kutsumalla pääkirjastona (puun juurisolmu) 
toString-rutiinia, saamme merkkijonoesityksen joka sisältää kaikki kirjastot, niiden kokoelman ja kokoelmien kirjat.


***C.*** **Syväsamuus.** Toteuta luokkiin equals-rutiinit. Kaksi oliota ovat samat jos ja vain jos olioiden kaikkien 
jäsenmuuttujien arvot ovat samat. Kokoelmatyyppisten jäsenmuuttujien sisältämien alkioiden tulee myös täsmätä, 
mutta niiden järjestyksellä ei ole väliä. 

***D.*** **Demonstrointi.** Edellä luotujen rutiinin toimintaa testataan käyttämällä niitä main-rutiinista käsin.
- Tee Kirjasto-olio pääkirjasto ja talleta se muuttujaan
- Lisää pääkirjastoon kaksi sivukirjastoa
- Tee kaikille edellä mainituille kirjastoille kaksi kokoelmaa ts. yhteensä kuusi eri oliota
- Lisää jokaiseen kokoelmaan vähintään kaksi kirjaa (yhteensä 12 eri oliota)
- Tulosta listaus kaikista kirjastoista kokoelmineen ja kirjoineen kutsumalla pääkirjasto-olion toString-rutiinia 
käyttäen 
- Luo kopio pääkirjasto-oliosta kutsumalla sen clone-rutiinia ja talleta se muuttujaan
- Vertaa alkuperäistä ja edellä tekemääsi kopiota equals-rutiinilla. Ovatko ne samat?


**Pisteytys**: 8 pistettä
- A-kohta 2 pistettä
- B-kohta 2 pistettä
- C-kohta 2 pistettä
- D-kohta 2 pistettä


## Tehtävä 3

Toteuta Javan Map-rajapinnan ympärille geneerinen kääreluokka RandomMap, joka toimii Map-rajapinnan mukaisesti muuten kuten 
olemassa oleva alkuperäinen Map-rajapinnan mukainen olio (eli delegoi toiminnot alkuperäiselle oliolle), mutta 
palauttaa (get) satunnaisen arvon alkuperäisestä arvojoukosta, mikäli pyydettyä avainta ei löydy alkuperäisen 
avainjoukosta. Käärittävä olio annetaan RandomMap-luokalle konstruktorin parametrina.

Huomaa, että toteutuksen tulee *geneerisesti* sopia yhteen minkä tahansa jo olemassa olevan Map-muotoisen 
olion kanssa. Lisäksi huomaa, että päätöksenteon pohjalla olevat arvo- ja avainjoukot voivat muuttua ohjelman 
suorituksen edetessä ja kääreen tulisi mukautua tähän.

Demonstroi toteuttamasi luokan käyttöä käärimällä jokin aiempi epätyhjä Map-olio ja nouda rajapinnan kautta 
kokoelmasta löytyvä tai puuttuva arvo.

Vinkki: IDE-ympäristö voi suureksi avuksi generoida alustavat versiot tarvittavista metodeista (esim. IDEA:ssa Ctrl-O ja Ctrl-I).

**Pisteytys**: 5 pistettä
- toimii pyydetyllä tavalla 2 pistettä
- toteutus on geneerinen 1 piste
- riippuu vain Map-rajapinnasta 1 piste
- demonstrointi 1 piste


## Tehtävä 4

Kurssi materiaalissa on esitelty Map-rajapinta ja sen toteuttavia luokkia, kuten HashMap. Map tallettaa 
avain-arvo-pareja. 

Tässä tehtävässä teemme geneerisen luokan *Triplet*, joka tallettaa avaimen ja kaksi siihen liittyvää 
arvoa ts. avain-arvo1-arvo2 -triplettejä. Avain ja arvot ovat geneeristä tyyppiä. Ne kaikki voivat olla eri 
tyyppiä.

Teemme myös rajapinnan *TripletMap*, joka määrittelee erilaisille tripletti toteutuksille yhteiset rutiinit.


***A.*** Luo luokka Triplet. Suunnittele ja toteuta luokkamuuttujat, joihin tiedot talletetaan. Tee luokalle 
konstruktori, joka alustaa tyhjän Triplet-olion. 

***B.*** Tee rajapinta *TripletMap* ja määrittele siinä seuraavat rutiinit. Ryhmittely ei näy rajapinnassa vaan sen 
osalta    
Ryhmä 1:  
- tripletin lisääminen: ```void put(K key, V value1, W value2)```
- tripletin ensimmäisen arvon palautus: ```V getFirstValue(K key) ```
- tripletin toisen arvon palautus: ```W getSecondValue(K key)```
- tripletin poisto: ```void remove(K key)```
- kaikkien triplettien poisto: ```void clear()```

Ryhmä 2:
- palauttaa kaikki avaimet: ```Set<K> keySet()```
- palauttaa kaikki ensimmäiset arvot: ```Set<V>> firstValues()```
- palauttaa kaikki toiset arvot: ```Set<W>> secondValues()```
- testaa löytyykö määrätty avain; true, jos löytyy: ```boolean containsKey(Object key)```
- testaa löytyykö määrätty arvopari; true, jos löytyy: ```boolean containsValue(Object value1, Object value2)```
- testaa, onko triplettejä; true, jos löytyy: ```boolean isEmpty()```
- montako triplettiä: ```int size()```


***C.*** Implementoi tekemääsi Triplet-luokkaan TripletMap-rajapinta. Lisää kaikki vaaditut rutiinien 
signatuurit Triplet-luokkaan.

***D.*** Toteuta ryhmän 1 rutiinit.

***E.*** Toteuta ryhmän 2 rutiinit.

**Pisteytys**: 9 pistettä
- A-kohta 2 pistettä
- B-kohta 2 pistettä
- C-kohta 1 pistettä
- D-kohta 2 pistettä
- E-kohta 2 pistettä


## Tehtävä 5

***A.*** Tutustu tehtäväpohjan luokkiin Ajoneuvo, HenkiloAuto ja KuormaAuto. Ajoneuvo-luokan geneerinen rutiini yhdista
toteuttaa kahden yhdistämisen edellä kuvattujen luokkien kontekstissa:

```Java
   public static <X extends Z, Y extends Z, Z extends Ajoneuvo> Set<Z> yhdista(Set<X> xs, Set<Y> ys){
        var tmp = new TreeSet<Z>();
        for (var x : xs) tmp.add(x);
        for (var y : ys) tmp.add(y);
        return tmp;
        }
```

Selitä, mitkä kaikki tyyppisignatuurit ovat yhteensopivia yhdistämisen tuloksena saadun listan kanssa. Luentomateriaalin
osa 17 Geneerisyys ja varianssi (sivu 18) graafi auttaa ymmärtämään asiaa. 

***B.*** Tutustu tehtäväpohjan luokkiin Ajoneuvo, HenkiloAuto ja KuormaAuto. Luokille on määritelty:
```java
abstract class Ajoneuvo {}
class HenkiloAuto extends Ajoneuvo {}
class KuormaAuto extends Ajoneuvo {}
```

Määritellään myös seuraavat joukot (Set):

```java
HashSet<Ajoneuvo> ajoneuvot = new HashSet<Ajoneuvo>();
HashSet<HenkiloAuto> henkiloautot = new HashSet<HenkiloAuto>();
HashSet<KuormaAuto> kuormaautot = new HashSet<KuormaAuto>();
```

Selvitä, voidaanko listat henkiloautot ja kuormaautot lisätä listaan ajoneuvot (HashSet.addAll). Perustele geneerisyyteen, 
varianssiin ja polymorfismiin nojaten, miksi lisäys onnistuu / ei onnistuu. Miksi listojen henkiloautot ja 
kuormaautot viittausta ei voida kuitenkaan sijoittaa muuttujaan ajoneuvot? Miten määrittely tulisi 
korjata, jotta sijoitus onnistuisi? Näytä ratkaisu koodina ja selosta myös, miksi ratkaisu toimii.

**Pisteytys**: 4 pistettä  
- A-kohta: 2 pistettä
- B-kohta: 2 pistettä
